clear;clc;close all
K = 20;
n = [-2000:4000]';
A = randn(1,K) - 1/2;
x = A .* ((n > 0) - (n - 1999 > 0));
Acor = x*x'/K;
Sd = 20*log10(fftshift(abs(fft2(Acor))));
%%
%plot(n,x)
%figure; imagesc(n,n,Acor)
%figure; imagesc(Sd)

%figure; plot(mean(x,2));
%plot(n,x,2)



clear; clc; close all
N = 0 : 1000;
phi = rand(1)*2*pi;
s = sin(0.25*N + phi);

w = randn(1, length(N));
v = filter(1, [1, -0.6], w);

x = s + w;

figure; imagesc(N,N,v)
figure; imagesc(v)