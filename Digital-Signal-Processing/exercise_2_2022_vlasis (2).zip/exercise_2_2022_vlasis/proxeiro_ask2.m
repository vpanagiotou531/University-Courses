%������ 1 ������� 1
a1_1 = fir1(30,0.48, 'low');
freqz(a1_1,1,512)
fvtool(a1_1,1,'OverlayedAnalysis','phase')

%������ 1 ������� 2
%���������
a1_2_high = firls(30,[0 0.2 0.3 1],[0 0 1 1]);
fvtool(a1_2_high,1,'OverlayedAnalysis','phase')

%������ 1 ������� 3
%������������
a1_3_low = firpm(30,[0 0.2 0.3 1],[1 1 0 0],'low')
freqz(a1_3_low,1,512)
fvtool(a1_3_low,1,'OverlayedAnalysis','phase')

%������ 1 ������� 3
%���������
a1_3_high = firpm(30,[0 0.2 0.3 1],[0 0 1 1],'high')
freqz(b,1,512)
fvtool(a1_3_high,1,'OverlayedAnalysis','phase')


%������ 2 ������� 1
load chirp.mat

t = (0:(length(y)-1))/Fs;
n = t*Fs;

a2_1_highpass = fir1(34,0.48,'high',chebwin(35,30));
freqz(a2_1_highpass,1)

sound(y)
sound(rand(size(y)))
sound(a2_1_highpass, Fs)

y1 = y + rand(size(y))
sound(y1)

yw = y + rand(size(y))
sound(yw)

d = designfilt('highpassfir', 'FilterOrder', 34, 'CutoffFrequency', .48, 'Window', 'chebwin')

yf = filtfilt(d,yw);
sound(yf)

dt = 0.0001
t = 0:dt:(length(yf) - 1); %length(y)-1
n = (0:100)*Fs;

figure
plot(n(1:100),yf(1:100))

fvtool(y,1,'OverlayedAnalysis','phase')

%subplot(2,1,1)
plot(t(1:100),y_1(1:100))
title('Original Signal')
ys = ylim;

%subplot(2,1,2)
plot(t(1:100),outhi(1:100))
title('Highpass Filtered Signal')
xlabel('Time (samples)')
ylim(ys)


t = (0:length(y)-1)/Fs;
bhi = fir1(34,0.48,'high',chebwin(35,30));
outhi = filtfilt(bhi,1,y);
plot(t(length(outhi)-101:length(outhi)-1),outhi(length(outhi)-101:length(outhi)-1))
title('Highpass Filtered Signal last 100 samples')
xlabel('Time (samples)')
%ylim(ys)



plot(t(length(y)-101:length(y)-1),y(length(y)-101:length(y)-1))
title('Original Bird Signal without white noise - Last 100 Samples')
xlabel('Time (samples)')


t = (0:length(y)-1)/Fs;
figure
plot(n(0:100), y(0:100))
title('Original Bird Signal without white noise - First 100 Samples')
xlabel('Time (samples)')
ylim(ys);


sound(outhi)


yo = (y1 - rand(size(y) )
sound(yo)
sound(y1)
sound(y1 - rand(size(y))



