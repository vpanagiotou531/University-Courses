%������ 3 ������� 1
load noisy.mat
sound(yw, Fs)

filterDesigner

t = (0:(length(y)-1))/Fs;
n = t*Fs;
fft(yw)
figure
plot(n(1:50),yw(1:50))

plot(abs(fftshift(fft(yw))));
fvtool(abs(fftshift(fft(yw))),1,'OverlayedAnalysis','phase')


load("Noisy.mat")
sound(yw)
pause(0.5)
clear sound




f = fir1(120,[0.3 0.7],'STOP');

kithara = filtfilt(f,1,yw)
sound(kithara,Fs)
figure
plot(t(121:371),kithara(121:371))

f1 = fir1(120,[0.3 0.7],'bandpass');
thoribos  = filtfilt(f1,1,yw)
sound(thoribos)
figure
plot(t(120:370),thoribos(120:370))


plot(abs(fftshift(fft(thoribos))));
freqz(thoribos,1)

F = fft(thoribos); 
pow = F.*conj(F);
figure
plot(pow)



%������ 2 ������� 2
load chirp.mat
load noisy.mat

b1 = firls(34,[0 0.45 0.5 1],[0 0 1 1]);
fvtool(b1,1,'OverlayedAnalysis','phase')

t = (0:(length(y)-1))/Fs;

dontcare = filtfilt(b1,1,yw)
sound(dontcare)
figure
plot(t(0:100),dontcare(0:100))

f5 = [0 0.45 0.5 1]
a5 = [0 0 1 1]
minmax = firpm(34,f5,a5)

minmax_apothoribopoihmeno = filtfilt(minmax,1,yw)
MSE = [mean(kithara.^2) mean(dontcare.^2) mean(minmax_apothoribopoihmeno).^2];






