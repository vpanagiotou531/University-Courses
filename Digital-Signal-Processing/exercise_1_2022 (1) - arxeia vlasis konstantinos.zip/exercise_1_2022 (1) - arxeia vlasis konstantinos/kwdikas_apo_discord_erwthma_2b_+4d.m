%y(n-1)= x(n-1) -1/2x(n) -1/2x(n-2)

h=[-1/2 , 1 ,-1/2];
%%
H=freqz(h);
%%
plot(abs(H))
%%
plot(angle(H))

n = 1:1:201;
x = cos(n * pi/4) - sin(n * pi/2) + (-1/2) .^ n;

plot(conv(x,h,"full"))


pk = 1/4 * ones(1,length(n));
plot(filter(n,pk,x))

plot(fft(x,1,length(n)))

plot( fftshift(x,length(n)) )

plot(abs(x));