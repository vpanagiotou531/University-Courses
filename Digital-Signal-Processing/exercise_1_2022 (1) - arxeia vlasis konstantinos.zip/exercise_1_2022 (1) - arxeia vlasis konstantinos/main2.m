Ts=0.02;    %fs=50Hz
Ts1=0.05;   %fs=20Hz
Ts2=0.1;    %Min Sampling Rate Limit fmins=2*f0, fs=10Hz, fmins=10Hz 
f0=5;
initial_phase=0;

sampling_reconstruction(Ts,f0,initial_phase)
sampling_reconstruction(Ts1,f0,initial_phase)
sampling_reconstruction(Ts2,f0,initial_phase)

