Ts=0.02;    %fs=50Hz
Ts1=0.005;   %fs=20Hz
Ts2=0.1;    %Min Sampling Rate Limit fmins=2*f0, fs=10Hz, fmins=10Hz 
f0=204;
initial_phase=0;

n = 0:10/Ts;
n1= 0:10/Ts1;
n2= 0:10/Ts2;
x = sin(2*pi*f0*n*Ts+initial_phase);
x1 = sin(2*pi*f0*n1*Ts1+initial_phase);
x2 = sin(2*pi*f0*n*Ts2+initial_phase);
%plot(t(1:1000),x_cont(1:1000)) % Plot original analog signal
% figure
% plot(n(1:100),x(1:100), '-x')%plot signal where fs=50Hz (Smallest Error)
figure(3)
plot(n(1:100),x1(1:100), '-x')%plot signal where fs=20Hz (Small error)
% figure
% plot(n(1:100),x2(1:100), '-x')%plot signal where fs=10Hz (Big error almost flatline)

sampling_reconstruction(0.005,204,0)

