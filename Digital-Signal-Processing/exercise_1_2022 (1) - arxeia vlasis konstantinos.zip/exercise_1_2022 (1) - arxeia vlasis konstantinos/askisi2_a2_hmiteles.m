b=[-1 1 -1];
a=[2 0 0];
w=[-pi:pi/100:pi];
figure(1)
[h,w] = freqz(b,a,'whole',2001)
title( ' freqz ')
% [H]-freqz(b,a,w);

plot(w/pi,20*log10(abs(h)))
ax = gca;
ax.YLim = [-100 20];
ax.XTick = 0:.5:2;
xlabel('Normalized Frequency (\times\pi rad/sample)')
ylabel('Magnitude (dB)')