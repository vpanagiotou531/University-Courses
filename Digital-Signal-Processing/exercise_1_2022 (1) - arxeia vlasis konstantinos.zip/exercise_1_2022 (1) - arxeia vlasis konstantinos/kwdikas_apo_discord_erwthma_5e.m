n = 0:100 
x=cos(n*pi/4)-sin(n*pi/2)+(-1/2).^n

b = [1, -0.5, -0.5];
a = [1,0,0];

y=filter(b,a,x);

f1=abs(fftshift(fft(x)))
f2=abs(fftshift(fft(y)))



t = 0:length(x)-1;  %index vector

figure
plot(t,f1)
figure
plot(t,f2)


figure (4)
plot(t,x(1,:))
hold on
plot(t,y(1,:))
legend('Input Data','Filtered Data')
title('First Row')