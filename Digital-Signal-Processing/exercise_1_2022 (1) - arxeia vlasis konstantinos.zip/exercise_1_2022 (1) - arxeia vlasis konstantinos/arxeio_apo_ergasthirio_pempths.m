
Ts = 0.1;
n-0:1/Ts
f0=5
x = sin(2*pi*5*n*Ts+pi/4);

figure
plot (n(1:10),x(1:10),'-x');

%askisi 2 erwthma 1
%y[n-1] = x[n-1] -1/2*x[n] - 1/2*x[n-2];


%h=[-1/2,1,1/2]



