Ts=0.02;    %fs=50Hz
Ts1=0.05;   %fs=20Hz
Ts2=0.1;    %Min Sampling Rate Limit fmins=2*f0, fs=10Hz, fmins=10Hz 
f0 = 5;
initial_phase=0;

n = 0:1/Ts; 
n1= 0:1/Ts1;
n2= 0:1/Ts2;
x = sin(2*pi*f0*n*Ts+initial_phase);
x1 = sin(2*pi*f0*n1*Ts1+initial_phase);
x2 = sin(2*pi*f0*n2*Ts2+initial_phase);

% plot(t(1:1000),x_cont(1:1000)) % Plot original analog signal
figure
plot(n*Ts,x,'x-');

figure
plot(n1*Ts1,x1,'o-');

figure
plot(n2*Ts2,x2,'x-');


% Analog Signal
%dt = 0.0005;
%t = -5:dt:5;
%x3 = sin(10*pi*t);

%figure
%plot(t,x3);











%SR = 1/Ts;
%dt = 1/SR;
%t = 0:dt:1;
%x = sin(2*pi*f0*n*Ts+initial_phase);

%SR1=1/Ts1; %sampling rate
%dt1=1/SR1;  %sampling interval
%t1=0:dt1:1;
%x1=sin(2*pi*f0*n*Ts1+initial_phase);

%SR2=1500; %sampling rate
%dt2=1/SR2;  %sampling interval
%t2=0:dt2:1;
%x2 = sin(2*pi*f0*n*Ts2+initial_phase);

%plot(t,x);
%xlabel('Time (s)'); ylabel('x');

%plot(t1,x1,'rx-');
%xlabel('Time (s)'); ylabel('x1');

%plot(t2,x2,'rx-');
%xlabel('Time (s)'); ylabel('x');
%legend('SR=200','SR=1500');
%


