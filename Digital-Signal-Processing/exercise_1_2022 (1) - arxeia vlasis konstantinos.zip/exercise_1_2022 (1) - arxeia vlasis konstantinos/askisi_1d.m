Ts=0.005;
n=0:10/Ts;
f0=4;
f2=204;
f3=4004;4
initial_phase=0;
x=sin(2*pi*f3*n*Ts);

plot(n,x,'-x')