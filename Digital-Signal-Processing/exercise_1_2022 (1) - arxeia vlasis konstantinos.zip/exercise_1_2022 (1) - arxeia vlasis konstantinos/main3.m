Ts=0.1;    %Min Sampling Rate Limit fmins=2*f0, fs=10Hz, fmins=10Hz 
f0=5;
initial_phase=pi/4;

sampling_reconstruction(Ts,f0,initial_phase)
