% Case c
figure (3)
b=[-1 1 -1];
a=[2 0 0];
w=[-pi:pi/100:pi];

[h w]=freqz(b,a,1024); % Calculate frequency response
phi=180*unwrap(angle(h))/pi;
subplot(2,1,1), plot(w,abs(h)),grid;
xlabel('Frequency (radians)'), ylabel('Magnitude')
subplot(2,1,2), plot(w,phi),grid;
xlabel('Frequency (radians)'), ylabel('Phase (degrees)')