Ts=0.05;   %Min Sampling Rate Limit fmins=2*f0, fs=10Hz, fmins=10Hz 
f0=4;       %fmins=8
f01=204;    %fmins=408
f02=4004;   %fmins=8008
initial_phase=0;

%Tsmin1=1/(2*f0)
%Tsmin2=1/(2*f01)
%Tsmin3=1/(2*f02)


n = 0:10/Ts;
x = sin(2*pi*f0*n*Ts+initial_phase);
x1 = sin(2*pi*f01*n*Ts+initial_phase);
x2 = sin(2*pi*f02*n*Ts+initial_phase);
figure
plot(n(1:100),x(1:100), '-x')%plot signal where fs=50Hz (Smallest Error)
figure
plot(n(1:100),x1(1:100), '-x')%plot signal where fs=20Hz (Small error)
figure
plot(n(1:100),x2(1:100), '-x')%plot signal where fs=10Hz (Big error almost flatline)
