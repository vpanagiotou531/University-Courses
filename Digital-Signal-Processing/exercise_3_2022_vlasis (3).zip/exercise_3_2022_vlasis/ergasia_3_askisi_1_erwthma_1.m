% ασκηση 1 ερωτημα 1

%τον ακολουθο κωδικα εκτελεσα για την ασκ 1 ερωτημα 1
% τον πηρα απ το βιβλιο Digital Signal processing Fundamentals-and-applications-3rd edition (εχει matlab)
b = [1,-1];
a=1;
%[h,w] = freqz(b,a,w);
[h,w]=freqz([1 -1],1,1024); %Calculate frequency response
phi=180*unwrap(angle(h))/pi;
subplot(2,1,1), plot(w,abs(h)),grid;
xlabel('Frequency (radians)'), ylabel('Magnitude')
subplot(2,1,2), plot(w,phi),grid;
xlabel('Frequency (radians)'), ylabel('Phase (degrees)')


b = [1,-1];
a=1;
[h,w]=freqz([1 -1],1,1024);
figure
plot(abs(h))
grid on
figure
plot(w)
grid on

