% ασκηση 1 ερωτημα 1

%w=[-pi:pi/100:pi];
b = [1,-1];
a = [1, 0]; %a = [1,0]; %a = 1; 
%[h,w] = freqz(b,a,w);
[h,w]=freqz(b,a,2001); % Calculate frequency response
phi=180*unwrap(angle(h))/pi;
figure
subplot(2,1,1), plot(w,abs(h)),grid;
xlabel('Frequency (radians)');
ylabel('Magnitude Response')

subplot(2,1,2), plot(w, phi); grid;
xlabel('Frequency (radians)');
ylabel('Phase (degrees)');


%τον ακολουθο κωδικα εκτελεσα για την ασκ 1 ερωτημα 1
% τον πηρα απ το βιβλιο Digital Signal processing Fundamentals-and-applications-3rd edition (εχει matlab)
figure
b = [1,-1];
a=1;
%[h,w] = freqz(b,a,w);
[h,w]=freqz([1 -1],1,1024); %Calculate frequency response
phi=180*unwrap(angle(h))/pi;
subplot(2,1,1), plot(w,abs(h)),grid;
xlabel('Frequency (radians)'), ylabel('Magnitude')
subplot(2,1,2), plot(w,phi),grid;
xlabel('Frequency (radians)'), ylabel('Phase (degrees)')


%plot(w,h),grid



% ασκηση 1 ερωτημα 2

% x(n) = cos(wo*n) , n = 0,1,...,1000

%n = linspace(0,1000)
n = 0:1:1000;
w0 = pi/16;
x_n = cos(w0*n);
figure
%plot
stem(n(1:100),x_n(1:100));  %'-o','MarkerIndices',1:2:length(y));
grid on

b = [1 -1];
a = 1;
y = filter(b,a,x_n);
figure
%plot 
stem(n(1:100),y(1:100))  %'-o','MarkerIndices',1:2:length(y));
grid on


