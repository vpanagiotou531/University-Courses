I = imread('photo.jpg');
%image(I)
imagesc(I)
colormap gray;


% link για μερικες παραγωγους εικονας στο ματλαμπ
% https://www.mathworks.com/help/matlab/ref/gradient.html
% https://stackoverflow.com/questions/27337431/partial-derivative-of-a-grayscale-image-using-matlab



%
%κωδικας απο ιντερνετ
u = imread('photo.jpg');
ux=Dx_plus(u);
figure; imshow(ux/255 +0.5);
uy=Dy_plus(u);
figure; imshow(uy/255 +0.5)

function dx_plus = Dx_plus(u, h)
%ορισμος συναρτησης Dx_plus(u, h)
if nargin==0;
    error('At least one input is needed');
elseif nargin>0
    if nargin==1
        h=1; % the distance between two pixels is defined as 1
    end
    [M, N, P]=size(u);

    if strcmp(class(u), 'double')==0
        u=double(u);
    end
    dx_plus=zeros([M, N, P]);
    for i=1:M-1
        for j=1:N
            dx_plus(i, j, :)=(u(i+1, j, :)-u(i, j, :))/h;
        end
    end
end

end % end of the function Dx_plus


function dy_plus = Dy_plus(u, h)
%ορισμος συναρτησης Dy_plus(u, h)
if nargin==0;
    error('At least one input is needed');
elseif nargin>0
    if nargin==1
        h=1; % the distance between two pixels is defined as 1
    end
    [M, N, P]=size(u);
    if strcmp(class(u), 'double')==0
        u=double(u);
    end
    dy_plus=zeros([M, N, P]);
    for i=1:M
        for j=1:N-1
            dy_plus(i, j, :)=(u(i, j+1, :)-u(i, j, :))/h;
        end
    end
end
end % end of the function Dy_plus
%





I = imread('photo.jpg');
%image(I)
figure
imagesc(I); title('αρχικη φωτο σε γκρι');

colormap gray;

%I(x,y) = disp(I);

b = [1 -1];
a = 1;
h = [1, -1]
figure
d_dx = filter(b,a,I);
%d/dx = filter(h,1,I)
colormap gray;
imagesc(d_dx); title('Μερική Παράγωγος ως προς x ---> dI(x,y)/dx');

%colormap gray;
%imagesc(yy)
%figure
%plot(y(1:100));
%figure
%plot(yy(1:100))
%colormap gray;

b = [1 -1];
a = 1;
h = [1, -1]
d_dy = filter(b,a,I')';
figure
imagesc(d_dy); title('Μερική Παράγωγος ως προς y ---> dI(x,y)/dy');
colormap gray;



b = [1 -1];
a = 1;
h = [1, -1]
figure
d2_dx2 = filter(b,a,d_dx);
%d/dx = filter(h,1,I)
colormap gray;
imagesc(d2_dx2); title('2η Μερική Παράγωγος ως προς x ---> d^2I(x,y)/dx^2');



b = [1 -1];
a = 1;
h = [1, -1]
d2_dy2 = filter(b,a,d_dy);
figure
imagesc(d2_dy2); title('2η Μερική Παράγωγος ως προς y ---> d^2I(x,y)/dy^2');
colormap gray;


b = [1 -1];
a = 1;
h = [1, -1]
figure
d2_dxdy = filter(b,a,(d_dx)');
%d/dx = filter(h,1,I)
colormap gray;
imagesc(d2_dx2); title(' Μερική Παράγωγος ως προς xy ---> d^2I(x,y)/dxdy');




b = [1 -1];
a = 1;
h = [1, -1]
d2_dydx = filter(b,a,d_dy);
figure
imagesc(d2_dy2); title('Μερική Παράγωγος ως προς yx ---> d^2I(x,y)/dydx');
colormap gray;



b = [1 -1];
a = 1;
h = [1, -1]

I = imread('photo.jpg');
%image(I)
figure
imagesc(I); title('αρχικη φωτο σε γκρι');

colormap gray;

d_dy = filter(b,a,I')';
d_dx = filter(b,a,I);
athroisma = d_dx + d_dy;
figure
imagesc(athroisma); title('αθροισμα πρωτων παραγωγων d/dx + d/dy');
colormap gray;

piliko = d_dx/d_dy;
figure
imagesc(athroisma); title('πηλικο πρωτων παραγωγων d/dx / d/dy');
colormap gray;

diafora = d_dx - d_dy;
figure
imagesc(athroisma); title('διαφορα πρωτων παραγωγων d/dx - d/dy');
colormap gray;




