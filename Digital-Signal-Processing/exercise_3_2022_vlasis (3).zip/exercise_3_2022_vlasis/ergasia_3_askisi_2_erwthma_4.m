clear;clc;close all
v = VideoReader('500fps_noisy.avi');
i = 0;
while hasFrame(v)
    i = i + 1;
    I = rgb2gray(im2double(readFrame(v)));
    x(i) = I(293,323);
end
y = x - mean(x);

Y = abs(fftshift(fft(y,1024)));
F = linspace(-250,250,1024);
plot(F,Y)



N=20;
hn1n2n3 = zeros(1);
%n1n2 = zeros(size(I));
for n1 = 1:size(v,3)
    for n2 = 1:size(v,3)
        for n3 = 1:size(v,3)
            if n1<=2*N && n2<=2*N
            hn1n2n3(n1,n2,n3)=(2*N+1)^(-2);
            end
        end
    end
end   


N=6;
Y_median = medfilt2(x, [N N])
figure
imagesc(x)
title('εικόνα photo-deg μετά από medfilt2() για Ν=6');


Y_median_fft = abs(fftshift(fft(Y_median,1024)));
F = linspace(-250,250,1024);
figure
plot(F,Y_median_fft)
colormap gray







