I_deg = imread('photo-deg.jpg');
imagesc(I_deg)
title('photo-deg αρχικη αφιλτραριστη εικόνα');
colormap gray;


%N=6;
%hn1n2 = zeros(1);
%n1n2 = zeros(size(I));
%for n1 = 1:size(I,2)
%    for n2 = 1:size(I,2)
%        if n1<=2*N && n2<=2*N
%            hn1n2(n1,n2)=(2*N+1)^(-2);
%       end
%    end
%end

%figure
%y_deg_median = medfilt2(I_deg)
% δε τρεχει αυτη συναρτηση, ειναι λαθος τα ορισματα   y_deg_median=medfilt2(hn1n2,I_deg,"full");
%colormap gray;
%imagesc(y_deg_median) 
%title('εικόνα photo-deg μετά από medfilt2() για Ν=6');

N=1;
J_1=medfilt2(I_deg, [N N])
figure
imagesc(J_1)
title('εικόνα photo-deg μετά από medfilt2() για Ν=1');
colormap gray;



















 