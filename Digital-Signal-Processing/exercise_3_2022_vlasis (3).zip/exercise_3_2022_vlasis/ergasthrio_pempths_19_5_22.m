%στα μη γραμμικα συστηματα δεν ισχυει η αρχη της υπερθεσης, οπως στα ΓΧΑ


w = linspace(0,pi);
%w=[-pi:pi/100:pi];
b = [1,-1];
a = [1]; %a = [1,0]; %a = 1; 
[h,w] = freqz(b,a,w);
%[h,w]=freqz(b,a,1024); % Calculate frequency response
phi=180*unwrap(angle(h))/pi;
subplot(2,1,1), plot(w,abs(h)),grid;
xlabel('Frequency (radians)'), ylabel('Magnitude')
subplot(2,1,2), plot(w,phi),grid;
xlabel('Frequency (radians)'), ylabel('Phase (degrees)')


h = [1, -1, 1]
wo = pi/16; 
n = [1:1:1000];
x = cos(wo*n);
result = filter(h, 1, x);
figure
plot(result(1:100));
figure
plot(x(1:100))















