% ασκηση 1 ερωτημα 2

% έχουμε σήμα εισόδου x(n) = cos(wo*n) , n = 0,1,...,1000

%n = linspace(0,1000)
n = 0:1:1000;
w0 = pi/16;
x_n = cos(w0*n);
figure
%plot
stem(n(1:100),x_n(1:100));  %'-o','MarkerIndices',1:2:length(y));
grid on

b = [1 -1];
a = 1;
y = filter(b,a,x_n);
figure
%plot 
stem(n(1:100),y(1:100))  %'-o','MarkerIndices',1:2:length(y));
grid on


