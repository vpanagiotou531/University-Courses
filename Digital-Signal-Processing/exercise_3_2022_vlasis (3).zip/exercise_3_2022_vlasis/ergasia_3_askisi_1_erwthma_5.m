I = imread('photo.jpg');
imagesc(I)
colormap gray;

im(I);


Y = filter2(H,I)


[H,f1,f2] = freqz2(h)


I = imread('photo.jpg');
imagesc(I)
colormap gray;
%[x y] = I;
%imagesc([x, y])



N=20;
hn1n2 = zeros(1);
%n1n2 = zeros(size(I));
for n1 = 1:size(I,2)
    for n2 = 1:size(I,2)
        if n1<=2*N && n2<=2*N
            hn1n2(n1,n2)=(2*N+1)^(-2);
        end
    end
end

figure
yyy=filter2(hn1n2,I,"full");
colormap gray;
imagesc(yyy) 
title('εικόνα μετά από filter2() για Ν=20');









