I_deg = imread('photo-deg.jpg');
imagesc(I_deg)
title('photo-deg αρχικη αφιλτραριστη εικόνα');
colormap gray;


N=20;
hn1n2 = zeros(1);
%n1n2 = zeros(size(I));
for n1 = 1:size(I,2)
    for n2 = 1:size(I,2)
        if n1<=2*N && n2<=2*N
            hn1n2(n1,n2)=(2*N+1)^(-2);
        end
    end
end

figure
yyy_deg=filter2(hn1n2,I_deg,"full");
colormap gray;
imagesc(yyy_deg) 
title('εικόνα photo-deg μετά από filter2() για Ν=20');












































