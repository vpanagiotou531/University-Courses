
% Part 1: Graph Construction - To initialize the Minessota graph and related matrices

% Constructing Minnesota Road graph from .mat file
% using certain geometrical characteristics embedded in
% .mat file to keep its proper shape when graphing it
load minnesota.mat
xy = [G.Nodes.XCoord G.Nodes.YCoord];
[s, t] = findedge(G);
figure(1);
plot(G, 'XData', xy(:,1), 'YData', xy(:,2), 'MarkerSize', 5);
title('Minnesota Road Network');

% Determine the size of the matrix A
n = numnodes(G);
A = zeros(n);

% Loop through the edges as defined by source (s) and
% target (t) vectors and fill the adjacency matrix A
for idx = 1:numel(s)
    i = s(idx);
    j = t(idx);
    
    % It's an undirected graph, so fill the adjacency
    % matrix A with 1s for both directions of edges
    A(i, j) = 1;
    A(j, i) = 1;
end

% Check to see if adjacency matrix A was made correctly
% Sum of all elements should be equal to non-zero elements
% From the for loop, we know they'll only be 1s, so we should be okay
if sum(sum(A)) ~= nnz(A)
    disp('Adjacency matrix A not constructed correctly');
end

% Initialize and compute degree matrix D
D = zeros(n);
for i = 1:n
    D(i, i) = sum(A(i, :));
end

% Check to see if degree matrix D was made correctly
% Number of nodes should be equal to non zero elements because
% the Minnesota Road graph is fully connected (i.e. you can 
% reach any node from any starting position in at most N steps,
% where N is the number of nodes minus 1 of the graph)
if n ~= nnz(diag(D))
    disp('Degree matrix D not constructed correctly');
end









% Part 2: Signal Construction - To create the signal we'll apply to the Minessota graph

% Information signal x
x = sin(sqrt(2) * 2 * pi * (1/n) * (0:n-1));
%x = randn(1, n);

% Additive white noise w
sigma = 0.35;
sigma_squared = sigma ^ 2;
w = sigma_squared .* randn(1, n);

% Noisy signal y
y = x + w;

% Signal to noise ratio of this instance
SNR = 10 .* log10(norm(x, 2)^2 / norm(w, 2)^2);










% Part 3: Graph Signal Display - To apply our graph signal (with and without noise)


% Overlay signal x on the graph as a heatmap
figure(2);
px = plot(G, 'XData', xy(:,1), 'YData', xy(:,2), 'MarkerSize', 5);
title('Minnesota Road Network with Signal Overlay');
colormap('jet'); % Set colormap for heatmap
colorbar; % Show colorbar
px.NodeCData = x; % Assign signal values to node colors

% Overlay signal y on the graph as a heatmap
figure(3);
py = plot(G, 'XData', xy(:,1), 'YData', xy(:,2), 'MarkerSize', 5);
title('Minnesota Road Network with Noisy Signal Overlay');
colormap('jet'); % Set colormap for heatmap
colorbar; % Show colorbar
py.NodeCData = y; % Assign signal values to node colors










Part 4: SNR Computations  - Compute the various SNRs that have been assigned 


% Different values of sigma (σ)
sigma_values = [0.125, 0.25, 0.5, 0.75];
SNR_values = zeros(size(sigma_values));
for i = 1:length(sigma_values)
    % Additive white noise w
    sigmas = sigma_values(i);
    w_var = sigmas .* (rand(1, n) - 0.5);

    % Calculate SNR for required cases
    SNR_values(i) = 10 * log10(norm(x, 2)^2 / norm(w_var, 2)^2);
end

% Display SNR values for different sigmas
disp('SNR values for different sigmas (σ):');
disp(SNR_values);









% Part 5: Graph Fourier Transform - To analyze the spectral components of the signal


% Symmetric Laplacian matrix construction and eigenanalysis
L_sym = eye(n) - D^(-1/2) * A * D^(-1/2);
[L_sym_eigen_vec, L_sym_eigen_val] = eig(L_sym);
lambdas_list = diag(L_sym_eigen_val);

decomp = L_sym_eigen_vec * L_sym_eigen_val * L_sym_eigen_vec';

if L_sym ~= decomp
    disp('Decomposition not constructed correctly');
end

% Compute the Graph Fourier Transform of x
x_gft = L_sym_eigen_vec' * x';

% Calculate the energy distribution across the spectrum
energy_distribution = abs(x_gft).^2;

% Since lambdas_list contains the eigenvalues,
% split the spectrum into low and high frequencies
% We'll examine both splitting by median and by mean,
% sum their energies and compare

%========%
% Median %
%========%
median_lambda = median(diag(L_sym_eigen_val));
median_low_freq_indices = find(diag(L_sym_eigen_val) < median_lambda);
median_high_freq_indices = find(diag(L_sym_eigen_val) >= median_lambda);
median_low_freq_energy = sum(energy_distribution(median_low_freq_indices));
median_high_freq_energy = sum(energy_distribution(median_high_freq_indices));
fprintf('Low Frequency Energy (Median): %f\n', median_low_freq_energy);
fprintf('High Frequency Energy (Median): %f\n', median_high_freq_energy);

if (median_low_freq_energy > 10 * median_high_freq_energy)
    fprintf(['Low frequency energy is far larger than high frequency' ...
        ' energy based on the median\n\n']);
elseif (median_low_freq_energy > median_high_freq_energy)
    fprintf(['Low frequency energy is larger than high frequency' ...
        ' energy based on the median\n\n']);
elseif (median_low_freq_energy < median_high_freq_energy)
    fprintf(['Low frequency energy is smaller than high frequency' ...
        ' energy based on the median\n\n']);
else
    fprintf(['Low frequency energy is smaller than high frequency' ...
        ' energy based on the median\n\n']);
end

%======%
% Mean %
%======%
mean_lambda = mean(diag(L_sym_eigen_val));
mean_low_freq_indices = find(diag(L_sym_eigen_val) < mean_lambda);
mean_high_freq_indices = find(diag(L_sym_eigen_val) >= mean_lambda);
mean_low_freq_energy = sum(energy_distribution(mean_low_freq_indices));
mean_high_freq_energy = sum(energy_distribution(mean_high_freq_indices));
fprintf('Low Frequency Energy (Mean): %f\n', mean_low_freq_energy);
fprintf('High Frequency Energy (Mean): %f\n', mean_high_freq_energy);

if (mean_low_freq_energy > 10 * mean_high_freq_energy)
    fprintf(['Low frequency energy is far larger than high frequency' ...
        ' energy based on the mean\n\n']);
elseif (mean_low_freq_energy > mean_high_freq_energy)
    fprintf(['Low frequency energy is larger than high frequency' ...
        ' energy based on the mean\n\n']);
elseif (mean_low_freq_energy < mean_high_freq_energy)
    fprintf(['Low frequency energy is smaller than high frequency' ...
        ' energy based on the mean\n\n']);
else
    fprintf(['Low frequency energy is smaller than high frequency' ...
        ' energy based on the mean\n\n']);
end









% Part 6: Graph Filtering Techniques - To construct various filters to denoise our graph signal


% Based on previous results, our signal contains mostly low-frequency
% components, meaning we'll choose a low-pass filter design. The eigenvalue
% that we will select for the cutoff is λ(1318) = 1, based on the results
% from both the median and the mean energy analysis done with the GFT.
% So, our ideal filter is φ(λ) = 1 when λ ≤ λ(1318),
% and φ(λ) = 0 when λ ≥ λ(1319) > λ(1318).

% Define the desired spectral response for a low-pass filter
% Desired response: 1 for lambda <= lambda_c, 0 otherwise
lambda_c = lambdas_list(1318);

% Create the ideal low-pass graph filter
h_d = double(lambdas_list <= lambda_c);

% Plot the ideal low-pass graph filter
figure(4);
plot(lambdas_list, h_d, 'LineWidth', 2);
xlabel('Eigenvalues (\lambda)');
ylabel('Filter Response (h_d)');
ylim([-0.5 1.5]);
title('Ideal Low-pass Graph Filter');
grid on;

% Compute the Graph Fourier Transform of x
y_gft = L_sym_eigen_vec' * y';

% Apply the ideal low-pass filter to the signal in the graph Fourier domain
y_filt_ideal_gft = h_d .* y_gft;

% Transform the filtered signal back to the vertex domain
x_filt_ideal = L_sym_eigen_vec * y_filt_ideal_gft;

% Plot the filtered signal overlaid on the graph
figure(5);
plot(G, 'XData', xy(:,1), 'YData', xy(:,2), 'MarkerSize', 5);
title('Minnesota Road Network with Filtered Signal Overlay (Ideal)');
colormap('jet');
colorbar;
hold on;
px_filt_ideal = plot(G, 'XData', xy(:,1), 'YData', xy(:,2), 'MarkerSize', 5);
px_filt_ideal.NodeCData = x_filt_ideal;
hold off;

% Filter order
M = 2139;


%============================= Window Method =============================%

% Define the windowed filter coefficients
h_window = fir1(M+1, lambdas_list(1318)/2, "low");

% Apply the windowed low-pass filter to the signal in the graph Fourier domain
y_filt_window_gft = h_window .* y_gft;

% Transform the filtered signal back to the vertex domain
x_filt_window = L_sym_eigen_vec * y_filt_window_gft;

% Ensure x_filt_window is a column vector
%x_filt_window_vec = x_filt_window(:, 1);
x_filt_window_vec = sum(x_filt_window, 2);

% Plot the windowed filtered signal overlaid on the graph
figure(6);
plot(G, 'XData', xy(:,1), 'YData', xy(:,2), 'MarkerSize', 5);
title('Minnesota Road Network with Windowed Filtered Signal Overlay');
colormap('jet');
colorbar;
hold on;
px_filt_window = plot(G, 'XData', xy(:,1), 'YData', xy(:,2), 'MarkerSize', 5);
px_filt_window.NodeCData = x_filt_window_vec;
hold off;


%========================== Least-Squares Method =========================%

% Define the least-squares filter coefficients
pass_cut_ls = [0, lambdas_list(1318)/2, lambdas_list(1319)/2, 1];
h_ls = firls(M+1, pass_cut_ls, [1 1 0 0]);

% Apply the LS low-pass filter to the signal in the graph Fourier domain
y_filt_ls_gft = h_ls .* y_gft;

% Transform the filtered signal back to the vertex domain
x_filt_ls = L_sym_eigen_vec * y_filt_ls_gft;

% Ensure x_filt_ls is a column vector
%x_filt_ls_vec = x_filt_ls(:, 1);
x_filt_ls_vec = sum(x_filt_ls, 2);

% Plot the least-squares filtered signal overlaid on the graph
figure(7);
plot(G, 'XData', xy(:,1), 'YData', xy(:,2), 'MarkerSize', 5);
title('Minnesota Road Network with Least-Squares Filtered Signal Overlay');
colormap('jet');
colorbar;
hold on;
px_filt_ls = plot(G, 'XData', xy(:,1), 'YData', xy(:,2), 'MarkerSize', 5);
px_filt_ls.NodeCData = x_filt_ls_vec;
hold off;


%============================= Min-Max Method ============================%

% Define the min-max filter coefficients
pass_cut_pm = [0, lambdas_list(1318)/2, lambdas_list(1329)/2, 1];
h_pm = firpm(M+1, pass_cut_pm, [1 1 0 0]);

% Apply the min-max low-pass filter to the signal in the graph Fourier domain
y_filt_pm_gft = h_pm .* y_gft;

% Transform the filtered signal back to the vertex domain
x_filt_pm = L_sym_eigen_vec * y_filt_pm_gft;

% Ensure x_filt_pm is a column vector
%x_filt_pm_vec = x_filt_pm(:, 1);
x_filt_pm_vec = sum(x_filt_pm, 2);

% Plot the min-max filtered signal overlaid on the graph
figure(8);
plot(G, 'XData', xy(:,1), 'YData', xy(:,2), 'MarkerSize', 5);
title('Minnesota Road Network with Min-Max Filtered Signal Overlay');
colormap('jet');
colorbar;
hold on;
px_filt_pm = plot(G, 'XData', xy(:,1), 'YData', xy(:,2), 'MarkerSize', 5);
px_filt_pm.NodeCData = x_filt_pm_vec;
hold off;

filtering_ideal = 10 .* log10(norm(y, 2)^2 / norm(x_filt_ideal, 2)^2);
filtering_window = 10 .* log10(norm(y, 2)^2 / norm(x_filt_window, 2)^2);
filtering_ls = 10 .* log10(norm(y, 2)^2 / norm(x_filt_ls, 2)^2);
filtering_pm = 10 .* log10(norm(y, 2)^2 / norm(x_filt_pm, 2)^2);

comp_window = filtering_ideal / filtering_window;
comp_ls = filtering_ideal / filtering_ls;
comp_pm = filtering_ideal / filtering_pm;

fprintf('Window method vs ideal filter for M = %d: %f\n', M, comp_window);
fprintf('Least-squares method vs ideal filter for M = %d: %f\n', M, comp_ls);
fprintf('Min-max method vs ideal filter for M = %d: %f\n', M, comp_pm);
