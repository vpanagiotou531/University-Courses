import random

import matplotlib.pyplot as plt
import numpy as np
from sympy import Point, Polygon
#from edge import get_edges

# Δημιουργια κλασης Edge, για να παραχθουν objects τυπου Edge για να χρησιμοποιηθουν παρακατω ως δομικα στοιχεια των δυο random polygons
# που θα παραχθουν και θα υπερτεθουν ωστε να ελεγξουμε αν τεμνονται , και εν τελει αν τεμνονται τοτε να παρουμε το 3ο πολυγωνο που σχηματιζεται
# απο την υπερθεση τους
class Edge:
    def __init__(self, point_a, point_b):
        self._support_vector = np.array(point_a)
        self._direction_vector = np.subtract(point_b, point_a)

    def get_intersection_point(self, other):
        t = self._get_intersection_parameter(other)
        return None if t is None else self._get_point(t)

    def _get_point(self, parameter):
        return self._support_vector + parameter * self._direction_vector

    def _get_intersection_parameter(self, other):
        A = np.array([-self._direction_vector, other._direction_vector]).T
        if np.linalg.matrix_rank(A) < 2:
            return None
        b = np.subtract(self._support_vector, other._support_vector)
        x = np.linalg.solve(A, b)
        return x[0] if 0 <= x[0] <= 1 and 0 <= x[1] <= 1 else None



def get_edges(polygon):
    """
    # το ορισμα polygon ειναι μια λιστα υλοποιημενη με δομη array [] (και οχι με δομη πλειαδας/tuple() )
    # (αυτο φαινεται και απο τη δηλωση polygon3 = list() μεσα στη συναρτηση "third_polygon_that_is...two_polygons(polygon1, polygon2))"
    # το οποιο περιεχει τοσα δισδιαστατα arrays σε πληθος οσα ειναι και οι κορυφες του (δλδ καθε δισδιαστατο array μεσα σε
    # καθε αντικειμενο-list polygon1, polygon2 και polygon3 ( το 3ο θα παραχθει αν και μονο αν τα 2 πρωτα τεμνονται σε τουλαχιστον 3 σημεια, ωστε
    # να παραχθει τουλαχιστον τριγωνο απο την υπερθεση τους (δε γινεται να υπαρξει διγωνο ή μονογωνο) )
    # Και απο τη συναρτηση get_edges(polygon)  επιστρεφεται : 1) ενα αντικειμενο/object τυπου Edge το οποιο περιεχει
    # τις κορυφεες (δλδ ολες τις δυαδες τιμων) του πολυγωνου που εχουμε βαλει σαν ορισμα
    # και 2) η αντιστοιχη θεση μνημης που εχει αποθηκευτει το object αυτο
    # πχ η εντολη print(get_edges(polygon1)) θα εκτυπωσει το εξης αποτελεσμα: <generator object get_edges at 0x0000017EF326A8F0>

    """
    for i in range(len(polygon)):
        yield Edge(polygon[i - 1], polygon[i]) # βαζουμε yield αντι για return διοτι θελουμε η συναρτηση get_edges(polygon)
        # να επιστρεψει ενα αντικειμενο (object) τυπου Edge, και οχι απλως να κανει return μια απλη τιμη, πχ 5.

# η συναρτηση third_polygon_that_is_made_from_the_intersection_of_the_other_two_polygons(polygon1, polygon2) υπολογιζει το πολυγωνο που
# σχηματιζεται/προκυπτει απο την υπερθεση των δυο αρχικων πολυγωνων που σχεδιασαμε (ΠΡΟΣΟΧΗ! : δε σχηματιζεται παντα polygon3 , διοτι μπορει
# τα δυο αρχικα πολυγωνα να μην τεμνοτναι πουθενα ή καποια-ες απο τις κορυφες του ενος να ακουμπαει ακριβως επιφανειακα πανω στο αλλο
# αν τουλαχιστον 1 απο τις κορυφες του ενος βρισκεται εντος του αλλου πολυγωνου, τοτε θα σχηαμτιστει polygon3 απο την υπερθεση τους

def third_polygon_that_is_made_from_the_intersection_of_the_other_two_polygons(polygon1, polygon2):
    """
    Τα πολυγονα που μπαινουν σαν ορισμα στη συναρτηση πρεπει να εχουν τις κορυφες τους γραμμενες/αριθμημενες απο δεξια προς τα αριστερα
    με βαση την αντιθετη φορα απο τους δεικτες του ρολογιου , ετσι οπως βλεπουμε εκτυπωμενες τις εικονες.
    Επισης, οταν εκτυπωσουμε ενα πολυγωνο ( δλδ εκτελεσουμε πχ την εντολη print(polygon1) ) οι κορυφες του που ειναι 2-διαστατα
    σημεια ( δλδ ζευγη (x,y) τυπου array ) θα εκτυπωθουν απο την αριστεροτερη προς τη δεξιοτερη οπως φαινονται στην εικονα που
    εμφανιζεται στα δεξια της κονσολας μεσω της εντολης plt.show() και της εντολης plot_polygon()
    πχ polygon1 = [[-0.8495590219572846, -0.5274935717247955], [0.8025415936262403, -0.5965961703697523], [0.44457717654130735, 0.895740550661049], [-0.5656416324087148, 0.82465116484851], [-0.8427592704768881, 0.5382906389909295]]
    """
    polygon3 = list()
    polygon3 += _get_vertices_lying_in_the_other_polygon(polygon1, polygon2)
    polygon3 += _get_edge_intersection_points(polygon1, polygon2)
    return _sort_vertices_anti_clockwise_and_remove_duplicates(polygon3)

# η συναρτηση αυτη επιστρεφει μια λιστα, η οποια περιεχει τις κορυφες (χωρις να λεει στη συνολικη λιστα
# ποια ανηκει σε καθε πολυγωνο) οι οποιες βρισκονται επανω στη διαγραμμιση ή εντος του αλλου πολυγωνου
def _get_vertices_lying_in_the_other_polygon(polygon1, polygon2):
    vertices = list()
    vertices += [vertex for vertex in polygon1 if _polygon_contains_point(polygon2, vertex)] # στη συνολικη λιστα
    # προστιθενται οι κορυφες του δευτερου πολυγωνου οι οποιες κεινται στο πρωτο πολυγωνο
    # (δλδ βρισκονται ακριβως στη διαγραμμιση του πρωτου πολυγωνου ή εντος αυτου)
    vertices += [vertex for vertex in polygon2 if _polygon_contains_point(polygon1, vertex)] # αντιστοιχα,
    # στη συνολικη λιστα προστιθενται και οι κορυφες του πρωτου πολυγωνου οι οποιες κεινται στο δευτερο πολυγωνο
    # (δλδ βρισκονται ακριβως στη διαγραμμιση του πρωτου πολυγωνου ή εντος αυτου)

    # η εντολη "vertex for vertex in polygon2 if _polygon_contains_point(polygon1, vertex)" κανει ελεγχο αν η κορυφη του
    # δευτερου πολυγωνου η οποια εχει θεση στη λιστα των κορυφων του 2ου πολυγωνου ιση με τη τιμη του μετρητη vertex,
    # αν βρισκεται εντος ή επανω ακριβως στο 1ο πολυγωνο (δλδ η κορυφη του 2ου πολυγωνου γεωμετρικα εμπεριεχεται
    # μεσα στο 1ο πολυγωνο, ετσι οπως το βλεπουμε απο τη φωτο που εκτυπωνεται)
    # το αντιστοιχο γινεται και για την απο πανω εντολη "vertex for vertex in polygon1 if _polygon_contains_point(polygon2, vertex)"

    # επισης, η συναρτηση _get_vertices_lying_in_the_other_polygon χρησιμοποιεται και για την κατασκευη του 3ου πολυγωνου
    # που παραγεται/σχηματιζεται απο την υπερθεση των δυο αρχικων πολυγωνων polygon1 και polygon2
    # στο 99.9% των περιπτωσεων αυτη η λιστα vertices που επιστρεφει η _get_vertices_lying_in_the_other_polygon(polygon1, polygon2)
    # ειναι κενη, λογω της τυχαιοτητας της παραγωγης των δυο αρχικων πολυγωνων (δλδ αυτη η συναρτηση προστεθηκε για να καλυψει και
    # την ακραια περιπτωση που καποια κορυφη του ενος πολυγωνου "ακουμπαει" πανω στο αλλο πολυγωνο ή βρισκεται εντος του
    return vertices

# συναρτηση η οποια επιστρεφει (σε μορφη λιστας υλοποιημενης με δομη δεδομενων array[]) τα σημεια τομης μεταξυ των ακμων
# των random polygons polygon1 και polygon2 που παραχθηκανε με τυχαιο τροπο απο τη συναρτηση
# υπενθυμιση: το καθε πολυγωνο polygon1, polygon2 και polygon3 ( το 3ο θα παραχθει αν και μονο αν τα 2 πρωτα τεμνονται σε τουλαχιστον 3 σημεια,
# ωστε να παραχθει τουλαχιστον τριγωνο απο την υπερθεση τους (δε γινεται να υπαρξει διγωνο ή μονογωνο) ) ειναι μια λιστα υλοποιημενη με δομη array[]
# και περιεχει εσωτερικα της τοσα δισδιαστατα arrays οσα και οι (δισδιαστατες) κορυφες της.
def _get_edge_intersection_points(polygon1, polygon2):
    intersection_points = list()
    for edge1 in get_edges(polygon1):
        for edge2 in get_edges(polygon2):
            intersection_point = edge1.get_intersection_point(edge2)
            if intersection_point is not None:
                intersection_points.append(intersection_point)
    return intersection_points

# συναρτηση που ελεγχει αν το πολυγωνο που τις δινεται ως ορισμα περιεχει το σημειο point , το οποιο point ειναι ενα δισδιαστατο array (x,y) που
# αναπαριστα ενα δισδιαστατο σημειο στο δισδιαστατο επιπεδο
def _polygon_contains_point(polygon, point):
    # η συναρτηση len(polygon) επιστρεφει το πληθος των κορυφων ( δλδ των ζευγων (x,y) )
    # του πολυγωνου polygon που παιρνει σαν ορισμα , αφου το polygon1, polygon2, και polygon3
    # ειναι το καθενα μια λιστα που περιεχει δυαδες , δλδ σημεια, που ειναι οι κορυφες του,
    # και μαλιστα ειναι τοποθετημενες/ταξινομημενες μεσα στη λιστα αυτη με βαση την αντιθετη
    # φορα των δεικτων του ρολογιου ετσι οπως βλεπουμε την εκτυπωμενη εικονα του πολυγωνου
    for i in range(len(polygon)):

        a = np.subtract(polygon[i], polygon[i - 1])
        b = np.subtract(point, polygon[i - 1])
        #print(type(a))
        #print(type(b))
        if np.cross(a, b) < 0:
            return False
    return True



def _sort_vertices_anti_clockwise_and_remove_duplicates(polygon, tolerance=1e-7):
    polygon = sorted(polygon, key=lambda p: _get_angle_in_radians(_get_bounding_box_midpoint(polygon), p))

    def vertex_not_similar_to_previous(_polygon, i):
        diff = np.subtract(_polygon[i - 1], _polygon[i])
        return np.linalg.norm(diff, np.inf) > tolerance

    return [p for i, p in enumerate(polygon) if vertex_not_similar_to_previous(polygon, i)]


def _get_angle_in_radians(point1, point2):
    return np.arctan2(point2[1] - point1[1], point2[0] - point1[0])

# η συναρτηση αυτη βρισκει το μεσο (δλδ το μεσαιο σημειο) του πολυγωνου 3 που της δινουμε ως ορισμα, το οποιο προκυπτει
# απο την υπερθεση των αρχικων δυο πολυγωνων polygon1 και polygon2
def _get_bounding_box_midpoint(polygon):
    x = [p[0] for p in polygon]
    y = [p[1] for p in polygon]
    return [(np.max(x) + np.min(x)) / 2., (np.max(y) + np.min(y)) / 2.]

# η συναρτηση αυτη παραγει ενα τυχαιο κυρτο πολυγωνο, και αν κανουμε εκτυπωση των κορυφων του (vertices) με την
# εντολη print(polygon1) οι κορυφες του θα εκτυπωθουν με φορα αντιθετη του ρολογιου ετσι οπως τις βλεπουμε στην εικονα
# που εκτυπωνουμε με τις εντολες plot_polygon(polygon1) και plt.show()

# Συναρτηση παραγωγης τυχαιου κυρτου πολυγωνου , με τις κορυφες του τοποθετημενες στη λιστα του με βαση την αντιθετη φορα των δεικτων
# του ρολογιου ετσι οπως βλεπουμε την εκτυπωμενη εικονα του πολυγωνου
def produce_a_random_polygon():
    return _sort_vertices_anti_clockwise_and_remove_duplicates(
       [[np.cos(x), np.sin(x)] for x in np.random.rand(random.randint(3, 6)) * 2 * np.pi])

# Συναρτηση εκτυπωσης της εικονας του πολυγωνου που της δινεται σαν ορισμα
def plot_polygon(polygon):
    if polygon: #ελεγχος εαν σαν ορισμα στη συναρτηση δινεται ενα οντως υπαρχον πολυγωνο που παραξαμε μεχρι στιγμης
        _polygon = list(polygon)
        _polygon.append(_polygon[0])
        x, y = zip(*_polygon)
        plt.plot(x, y, 'o-')
        plt.fill(x, y, alpha=0.25)



#κομματι "main"

polygon1 = produce_a_random_polygon()
polygon2 = produce_a_random_polygon()
polygon3 = third_polygon_that_is_made_from_the_intersection_of_the_other_two_polygons(polygon1, polygon2)

#isIntersection = polygon1.intersection(polygon2)

plot_polygon(polygon1)
plot_polygon(polygon2)
plot_polygon(polygon3)
plt.show()
#print(isIntersection)
if len(polygon3) > 3:
    print("the intersection points between the two polygons that we randomly constructed are the edges of the 3rd polygon that is produced, which are the following:")
    print(polygon3)
else:   # δλδ αν το polygon3 που παραγεται απο τα 2 πρωτα δεν εχει καθολου ακμες (δλδ δεν παραγεται καν), τοτε σημαινει
        # οτι τα δυο αρχικα κυρτα πολυγωνα που παραχθηκαν με τυχαιο τροπο δεν "ακουμπανε" αμα τα υπερθεσουμε, αρα δεν
        # εχουμε intersection μεταξυ των αρχικων πολυγωνων
        # τα polygon1, polygon2, polygon3 ειναι λιστες, οποτε αν υφιστανται ως παραγμενες οντοτητες, θα πρεπει να περιεχουν
        # τουλαχιστον 3 σημεια (και αρα τουλαχιστον 3 ακμες) (δλδ να ειναι τουλαχιστον τριγωνα).
        # Οποτε γι αυτο τον λογο κανουμε ελεγχο του μηκους τους και τα αντιμετωπιζουμε σαν λιστες
        # Αρα ο ελεγχος ειναι len(polygon)>=3, ωστοσο αν βαζαμε ελεγχο len(polygon)>0 δε θα ηταν λαθος διοτι δε δυναται
        # να υπαρξει διγωνο ή μονογωνο, οποτε αναγκαστικα τα στοιχεια της καθε πολυγωνικης λιστας (δλδ καθε πολυγωνου εκ των
        # polygon1, polygon2, polygon3) παντα θα ειναι >=3, οποτε το >0 μας καλυπτει και αυτο.
    print("the two polygons that we constructed randomly, do not intersect")

#print(type([vertex for vertex in polygon1 if _polygon_contains_point(polygon2, vertex)]))
#print(_get_bounding_box_midpoint(polygon3))
#print(polygon1)
#print(polygon3.p[1])
#print(_get_vertices_lying_in_the_other_polygon(polygon1, polygon2))
