import random
import matplotlib.pyplot as plt
import numpy as np


"""

def RandomLineSegment():
    x1 = random.uniform(-1,1)
    y1 = random.uniform(-1,1)
    syntetagmenes1 = (x1,y1)
    print(syntetagmenes1)

    x2 = random.uniform(-1,1)
    y2 = random.uniform(-1,1)
    syntetagmenes2 = (x2,y2)
    print(syntetagmenes2)

    x_values = [x1,x2]
    y_values = [y1,y2]
    plt.plot(x_values, y_values)
    plt.show()


RandomLineSegment()
RandomLineSegment()

"""
line_segment_as_vector = []  # πινακας που περιεχει καθε line segment που παραχθηκε σε μορφη διανυσματος

line_segments_array = []  # πινακας οπου καθε κελι του περιέχει τις συντεταγμενες του αρχικου και τελικου σημειου ενος ευθυγραμμου τμηματος


# συνολικα ο πινακας θα περιεχει n ευθυγραμμα τμηματα, οσα και το ορισμα n της RandomLineSegments(n)

# η συναρτηση RandomLineSegments(n) κατασκευαζει n (το πληθος) τυχαια line segments

def RandomLineSegments(n):  # n ειναι ο αριθμος των line segments που σχεδιαζει η συναρτηση

    # κατασκευη n (το πληθος) segments, εκτυπωση των συντεταγμενων των ακρων τους και εκτυπωση των εικονων τους

    print("the line segments that we constructed are :")

    for j in range(n):
        # συντεταγμενες του αριστερου ακρου του ευθυγραμμου τμηματος
        x1 = random.uniform(-1, 1)
        y1 = random.uniform(-1, 1)
        syntetagmenes_prwtoy_shmeiou = (x1, y1)
        # print(syntetagmenes_prwtoy_shmeiou)

        # συντεταγμενες του δεξιου ακρου του ευθυγραμμου τμηματος
        x2 = random.uniform(-1, 1)
        y2 = random.uniform(-1, 1)
        syntetagmenes_deyterou_shmeiou = (x2, y2)
        # print(syntetagmenes_deyterou_shmeiou)

        # σχεδιασμος της γραφικης παραστασης του ευθυγραμμου τμηματος
        x_values = [x1, x2]
        y_values = [y1, y2]
        plt.plot(x_values, y_values)
        plt.show()

        # συνολικες συντεταγμενες του ευθυγραμμου τμηματος
        # segment_coordinates = (syntetagmenes_prwtoy_shmeiou, syntetagmenes_deyterou_shmeiou)

        # αποθηκευση των δεδομενων του ευθυγραμμου τμηματος στον πινακα line_segments_array = [n]
        # line_segments_array[j] = segment_coordinates
        # line_segments_array.append(segment_coordinates)

        # αποθηκευση των δεδομενων του ευθυγραμμου τμηματος no. j στον πινακα line_segments_array = [n]
        # και εκτυπωση τους

        line_segments_array.append((syntetagmenes_prwtoy_shmeiou, syntetagmenes_deyterou_shmeiou))
        print("line segment no.", j)
        print(line_segments_array[j])

    return n  # η συναρτηση RandomLineSegments(n) επιστρεφει το πληθος των ευθ.τμηματων που κατασκευασε


# print(line_segments_array[j])
#  return(line_segments_array[j])

# print(type(RandomLineSegment()))

# κληση της συναρτησης RandomLineSegments(n) για παραγωγη n (το πληθος) τυχαιων ευθυγραμμων τμηματων
# RandomLineSegments(5)

n = RandomLineSegments(2)


# η συναρτηση αυτη ελεγχει ανα ζευγη τα ευθυγραμμα τμηματα αν τεμνονται
def LineSegmentsIntersectionCheck(n):
    """
    for j in range(n):
        line_segment_for_check = line_segments_array[j]
        print("line segment for check of intersection with other segments:", line_segment_for_check)
        print("this segment will be checked with segments:", j+1, "to", j+n-1)
        #for i in range(n):
        # οριζω ως διανυσμα (vector) το j-οστο ευθυγραμμο τμημα
        line_segment_as_vector[j] = np.array( [ line_segments_array[j][1][0] - line_segments_array[j][0][0],
                                                line_segments_array[j][1][1] - line_segments_array[j][0][1], 0 ] )
                                              # (χβ - χα, yβ - yα, 0)
                                              # δλδ (χ_τελικου_σημειου - χ_αρχικου_σημειου, y_τελικου_σημειου - y_αρχικου_σημειου, 0)
                                              # θεωρουμε οτι τα διανυσματα εχουν συνιστωσα στον z-αξονα ιση με 0 (δλδ ειναι 2d διανυσματα)
    """
    # οριζω ως διανυσμα (vector) το j=0-οστο ευθυγραμμο τμημα , και θα ειναι το διανυσμα ΑΒ

    line_segment_0_as_vector = vector_AB = np.array([line_segments_array[0][1][0] - line_segments_array[0][0][0],
                                                     line_segments_array[0][1][1] - line_segments_array[0][0][1], 0])
    # (χβ - χα, yβ - yα, 0)
    # δλδ (χ_τελικου_σημειου - χ_αρχικου_σημειου, y_τελικου_σημειου - y_αρχικου_σημειου, 0)
    # θεωρουμε οτι τα διανυσματα εχουν συνιστωσα στον z-αξονα ιση με 0 (δλδ ειναι 2d διανυσματα)

    # οριζω ως διανυσμα (vector) το j=1-οστο ευθυγραμμο τμημα , και θα ειναι το διανυσμα ΓΔ
    line_segment_1_as_vector = vector_GD = np.array([line_segments_array[1][1][0] - line_segments_array[1][0][0],
                                                     line_segments_array[1][1][1] - line_segments_array[1][0][1], 0])
    # (χβ - χα, yβ - yα, 0)
    # δλδ (χ_τελικου_σημειου - χ_αρχικου_σημειου, y_τελικου_σημειου - y_αρχικου_σημειου, 0)
    # θεωρουμε οτι τα διανυσματα εχουν συνιστωσα στον z-αξονα ιση με 0 (δλδ ειναι 2d διανυσματα)

    result_cross_product_AB_x_GD = np.cross(vector_AB, vector_GD)

    print("the result of the cross product between vectors AB and ΓΔ is: ", result_cross_product_AB_x_GD)

    # εστω Α(χα,yα,0) το πρωτο ακρο του j=0-στου ευθ.τμηματος, δλδ Α( line_segments_array[0][0][0] , line_segments_array[0][0][1] , 0 )
    # και εστω Β(χβ,yβ,0) το δευτερο ακρο του j=0-στου ευθ.τμηματος, δλδ Β( line_segments_array[0][1][0], line_segments_array[0][1][1],0 )
    # εστω Γ(χγ,yγ,0) το πρωτο ακρο του j=1-στου ευθ.τμηματος, δλδ Γ( line_segments_array[1][0][0], line_segments_array[1][0][1] , 0 )
    # και εστω Δ(χδ,yδ,0) το δευτερο ακρο του j=1-στου ευθ.τμηματος, δλδ Δ( line_segments_array[1][1][0], line_segments_array[1][1][1], 0 )

    # με τη παραπανω διαδικασια  φτιαξαμε τα διανυσματα ΑΒ = ΟΒ-ΟΑ  και  ΓΔ = ΟΔ - ΟΓ
    # και υπολογισαμε το εξωτερικο γινομενο των διανυσματων ΑΒ x ΓΔ (οπου ΑΒ = ΟΒ - ΟΑ , ΓΔ = ΟΔ - ΟΓ)

    # για να ελεγξουμε αν το j=0-οστο και το j=1-οστο ευθυγ.τμημα τεμνονται, θα πρεπει να φτιαξουμε και τα εξης διανυσματα:
    # ΑΔ = ΟΔ - ΟΑ = ( χδ - χα , yδ - yα, 0 ) = (line_segments_array[1][1][0] -  line_segments_array[0][0][0],
    #                                             line_segments_array[1][1][1] - line_segments_array[0][0][1] , 0 )

    # ΓΒ = ΟΒ - ΟΓ = ( χβ - χγ, yβ - yγ , 0 ) = (line_segments_array[0][1][0] - line_segments_array[1][0][0],
    #                                               line_segments_array[0][1][1] - line_segments_array[1][0][1], 0 )

    # ΑΓ = ΟΓ - ΟΑ = ( χγ - χα , yγ - yα, 0 ) = (line_segments_array[1][0][0] - line_segments_array[0][0][0] ,
    #                                             line_segments_array[1][0][1] - line_segments_array[0][0][1], 0 )

    # ΓΑ = ΟΑ - ΟΓ = ( χα - χγ , yα - yγ , 0 ) = ( line_segments_array[0][0][0] - line_segments_array[1][0][0],
    #                                              line_segments_array[0][0][1] - line_segments_array[1][0][1], 0 )

    vector_AD = np.array([line_segments_array[1][1][0] - line_segments_array[0][0][0],
                          line_segments_array[1][1][1] - line_segments_array[0][0][1], 0])

    vector_GB = np.array([line_segments_array[0][1][0] - line_segments_array[1][0][0],
                          line_segments_array[0][1][1] - line_segments_array[1][0][1], 0])

    vector_AG = np.array([line_segments_array[1][0][0] - line_segments_array[0][0][0],
                          line_segments_array[1][0][1] - line_segments_array[0][0][1], 0])

    vector_GA = np.array([line_segments_array[0][0][0] - line_segments_array[1][0][0],
                          line_segments_array[0][0][1] - line_segments_array[1][0][1], 0])

    # τωρα θα υπολογισουμε το εξωτ. γινομενο ΑΔ x ΓΒ

    result_cross_product_AD_x_GB = np.cross(vector_AD, vector_GB)
    print("the result of the cross product between vectors AΔ and ΓΒ is: ", result_cross_product_AD_x_GB)

    # τωρα θα υπολογισουμε το εξωτ. γινομενο ΑΔ x ΑΒ
    result_cross_product_AD_x_AB = np.cross(vector_AD, vector_AB)

    # τωρα θα υπολογισουμε το εξωτ. γινομενο ΑΓ x ΑΒ
    result_cross_product_AG_x_AB = np.cross(vector_AG, vector_AB)
    print("the result of the cross product between vectors AΓ and ΑΒ is: ", result_cross_product_AG_x_AB)

    # τωρα θα υπολογισουμε το εξωτ. γινομενο ΓΒ x ΓΔ
    result_cross_product_GB_x_GD = np.cross(vector_GB, vector_GD)
    print("the result of the cross product between vectors ΓΒ and ΓΔ is: ", result_cross_product_GB_x_GD)

    # τωρα θα υπολογισουμε το εξωτ. γινομενο ΓA x ΓΔ
    result_cross_product_GA_x_GD = np.cross(vector_GA, vector_GD)
    print("the result of the cross product between vectors ΓΑ and ΓΔ is: ", result_cross_product_GA_x_GD)

    # abs(result_cross_product_AD_x_GB)
    # print(type(result_cross_product_AD_x_GB[2]))
    # print(result_cross_product_AD_x_GB[2])
    # print(abs(result_cross_product_AD_x_GB))

    if (result_cross_product_AG_x_AB[2] * result_cross_product_AD_x_AB[2] <= 0) and (
            result_cross_product_GB_x_GD[2] * result_cross_product_GA_x_GD[2] <= 0):
        print("these two line segments  intersect")
        return True
    else:
        print("these two line segments DO NOT intersect")
        return False


#LineSegmentsIntersectionCheck(n)




xa = line_segments_array[0][0][0]
ya = line_segments_array[0][0][1]

xb = line_segments_array[0][1][0]
yb = line_segments_array[0][1][1]

xg = line_segments_array[1][0][0]
yg = line_segments_array[1][0][1]

xd = line_segments_array[1][1][0]
yd = line_segments_array[1][1][1]


a1 = (yb-ya)/(xb-xa)
a2 = (yg-yd)/(xg-xd)
b1 = ya-a1*xa
b2 = yg-a2*xg

#y = a1*x + b1
#y_tonos = a2*x + b2

def function_y(x):
    y = a1 * x + b1
    return y

def function_y_tonos(x):
    y_tonos = a2 * x + b2
    return y_tonos


if (LineSegmentsIntersectionCheck(n) == False):
    print("there is no intersection point between the two segments ")
else: # δλδ αν (LineSegmentsIntersectionCheck(n) == True)
        print("there is intersection point between two segments, and we should solve the 2x2 system")

        x_tomhs = -(b2-b1)/(a2-a1)
        y_tomhs = a1 * x_tomhs + b1
        print("the intersection point of the two segments is", x_tomhs, y_tomhs)



#sos
# το αρχειο αυτο exei μια διαφορα με το testarimsa3 στον ελεγχο αυτον:
#
# if (result_cross_product_AG_x_AB[2] * result_cross_product_AD_x_AB[2] <= 0) and (
#             result_cross_product_GB_x_GD[2] * result_cross_product_GA_x_GD[2] <= 0):
#         print("these two line segments  intersect")
#         return True
#     else:
#         print("these two line segments DO NOT intersect")
#         return False





