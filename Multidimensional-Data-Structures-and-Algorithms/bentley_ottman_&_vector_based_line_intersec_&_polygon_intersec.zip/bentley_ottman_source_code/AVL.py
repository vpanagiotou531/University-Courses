class TreeNode(object):
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None
        self.height = 1

class AVL_Tree(object):

    def insert(self, root, key):

        # Step 1 - Perform normal BST
        if not root:
            return TreeNode(key)
        elif key < root.val:
            root.left = self.insert(root.left, key)
        elif key > root.val:
            root.right = self.insert(root.right, key)

        elif key == root.val:
            return root

        # Step 2 - Update the height of the
        # ancestor node
        root.height = 1 + max(self.getHeight(root.left),
                              self.getHeight(root.right))

        # Step 3 - Get the balance factor
        balance = self.getBalance(root)

        # Step 4 - If the node is unbalanced,
        # then try out the 4 cases
        # Case 1 - Left Left
        if balance > 1 and key < root.left.val:
            return self.rightRotate(root)

        # Case 2 - Right Right
        if balance < -1 and key > root.right.val:
            return self.leftRotate(root)

        # Case 3 - Left Right
        if balance > 1 and key > root.left.val:
            root.left = self.leftRotate(root.left)
            return self.rightRotate(root)

        # Case 4 - Right Left
        if balance < -1 and key < root.right.val:
            root.right = self.rightRotate(root.right)
            return self.leftRotate(root)

        return root

    def find_lowest(self, root):

        if not root.left:
            return root;
        else:
            return self.find_lowest(root.left)

    def pop_lowest(self,root):

        lowest = self.find_lowest(root)

        new_root = self.delete(root,lowest.val)

        return [lowest.val, new_root]

    def find_highest(self, root):

        if not root.right:
            return root;
        else:
            return self.find_highest(root.right)

    def pop_highest(self,root):

        highest = self.find_highest(root)

        new_root = self.delete(root,highest.val)

        return [highest.val, new_root]

    # Recursive function to delete a node with
    # given key from subtree with given root.
    # It returns root of the modified subtree.
    def delete(self, root, key):

        # Step 1 - Perform standard BST delete
        if not root:
            return root

        elif key < root.val:
            root.left = self.delete(root.left, key)

        elif key > root.val:
            root.right = self.delete(root.right, key)

        else:
            if root.left is None:
                temp = root.right
                root = None
                return temp

            elif root.right is None:
                temp = root.left
                root = None
                return temp

            temp = self.getMinValueNode(root.right)
            root.val = temp.val
            root.right = self.delete(root.right,
                                     temp.val)

        # If the tree has only one node,
        # simply return it
        if root is None:
            return root

        # Step 2 - Update the height of the
        # ancestor node
        root.height = 1 + max(self.getHeight(root.left),
                              self.getHeight(root.right))

        # Step 3 - Get the balance factor
        balance = self.getBalance(root)

        # Step 4 - If the node is unbalanced,
        # then try out the 4 cases
        # Case 1 - Left Left
        if balance > 1 and self.getBalance(root.left) >= 0:

            return self.rightRotate(root)

        # Case 2 - Right Right
        if balance < -1 and self.getBalance(root.right) <= 0:
            return self.leftRotate(root)

        # Case 3 - Left Right
        if balance > 1 and self.getBalance(root.left) < 0:
            root.left = self.leftRotate(root.left)
            return self.rightRotate(root)

        # Case 4 - Right Left
        if balance < -1 and self.getBalance(root.right) > 0:
            root.right = self.rightRotate(root.right)
            return self.leftRotate(root)

        return root

    def leftRotate(self, z):
        y = z.right
        T2 = y.left

        # Perform rotation
        y.left = z
        z.right = T2

        # Update heights
        z.height = 1 + max(self.getHeight(z.left),
                           self.getHeight(z.right))
        y.height = 1 + max(self.getHeight(y.left),
                           self.getHeight(y.right))
        
        # Return the new root
        return y

    def rightRotate(self, z):

        y = z.left
        T3 = y.right

        # Perform rotation
        y.right = z
        z.left = T3

        # Update heights
        z.height = 1 + max(self.getHeight(z.left),
                           self.getHeight(z.right))
        y.height = 1 + max(self.getHeight(y.left),
                           self.getHeight(y.right))

        # Return the new root
        return y

    def getHeight(self, root):
        if not root:
            return 0

        return root.height

    def getBalance(self, root):
        if not root:
            return 0

        return self.getHeight(root.left) - self.getHeight(root.right)

    def getMinValueNode(self, root):
        if root is None or root.left is None:
            return root

        return self.getMinValueNode(root.left)

    def printInorder(self,root):
        if root:
            self.printInorder(root.left)
            print("{}{}".format(root.val,self.getHeight(root)))
            self.printInorder(root.right)

    def recalculate_segments(self,root,y):#recalculate the value of each segment
        if root:
            self.recalculate_segments(root.left,y)
            root.val.recalculate_value(y)
            self.recalculate_segments(root.right,y)

    def neighbors(self,root,node,info,found):
        if root and found[0] != 2:
            self.neighbors(root.left,node,info,found)
            if root.val == node:
                info[1] =  root.val
                found[0] = 1
            elif found[0] == 0:
                info[0] = root.val
            elif found[0] == 1 and root.val != info[1]:
                info[2] = root.val
                found[0] = 2
                return;

            self.neighbors(root.right,node,info,found)

    def swap(self, root, info, found, previous):
        if root and found[0] != 2:
            previous = [root]
            self.swap(root.left,info, found, previous)

            if root.val == info[1]:
                root.val = info[0]
                found[0] += 1

            elif root.val == info[0]:
                root.val = info[1]
                found[0]+= 1

            previous = [root];
            self.swap(root.right,info, found, previous)
