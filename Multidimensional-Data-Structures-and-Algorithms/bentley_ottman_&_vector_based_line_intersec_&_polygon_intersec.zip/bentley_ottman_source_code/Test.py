import random
import matplotlib.pyplot as plt
from Sweep import Sweep_algorithm
from matplotlib.pyplot import figure
import time
from SweepIntersectorLib.SweepIntersector import SweepIntersector

figure(figsize=(14, 9), dpi=80)

segList = []
me = []
intersec_list = []
above_intersec_list = []

min = -8
max = 8
# create some random segments
for i in range(40):
    vs = (random.uniform(min,max),random.uniform(min,max))
    ve = (random.uniform(min,max),random.uniform(min,max))
    segList.append( (vs,ve) )

start = time.time()
Sweep_algorithm(segList,intersec_list,above_intersec_list)
end = time.time()

print("Time:{}".format(end - start))

# plot original segments
for seg in segList:
    vs,ve = seg
    plt.plot([vs[0], ve[0]], [vs[1], ve[1]], 'g:')
    plt.plot([vs[0],ve[0]],[vs[1],ve[1]], 'b.')

for seg in intersec_list:
    plt.plot(seg.x,seg.y,'r.')

for seg in above_intersec_list:
    plt.plot(seg.x,seg.y,'r.')

plt.show()