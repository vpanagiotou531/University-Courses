from AVL import AVL_Tree
from Segment import Segment
from Point import Point

def Sweep_algorithm(origSegList,intersec_list,above_intersec_list):

    event_queue = AVL_Tree()
    structure_queue = AVL_Tree()
    seg_list = []
    event_queue_root = None
    structure_queue_root = None

    for segIndex, seg in enumerate(origSegList):
        point_1 = Point(seg[0],0)
        point_2 = Point(seg[1],0)

        segment = Segment( point_1, point_2 )

        point_1.parent_seg = segment
        point_2.parent_seg = segment

        event_queue_root = event_queue.insert(event_queue_root,point_1)
        event_queue_root = event_queue.insert(event_queue_root,point_2)

        seg_list.append(segment)

    while event_queue_root:
        info_1 = [None, None, None];
        found_1 = [0]
        found_2 = [0]
        previous = [None]
        i = event_queue.pop_highest(event_queue_root)

        event_queue_root = i[1]

        if i[0].type_of_point == 0:#top point only insert

            structure_queue.recalculate_segments(structure_queue_root,i[0].y)

            structure_queue_root = structure_queue.insert(structure_queue_root, i[0].parent_seg)
            structure_queue.neighbors(structure_queue_root, i[0].parent_seg, info_1, found_1)
            #check for intersections among the pairs
            if info_1[0] != None and info_1[2] != None:

                temp = info_1[0].intersection(info_1[1])
                if temp != None:
                    event_queue_root = event_queue.delete(event_queue_root, temp)

            if info_1[0] != None and info_1[1] != None:

                temp = info_1[0].intersection(info_1[1])
                if temp != None:
                    event_queue_root = event_queue.insert(event_queue_root, temp)
                    intersec_list.append(temp)


            if info_1[1] != None and info_1[2] != None:

                temp = info_1[1].intersection(info_1[2])
                if temp != None:
                    event_queue_root = event_queue.insert(event_queue_root, temp)
                    intersec_list.append(temp)


        elif i[0].type_of_point == 1:#bottom point, delete segment and insert intersecions below line

            structure_queue.neighbors(structure_queue_root, i[0].parent_seg, info_1, found_1)
            #check if the bottom points neighboors intersect and delete it
            if info_1[0] != None and info_1[2] != None:

                temp = info_1[0].intersection(info_1[2])

                if temp != None and temp.y < i[0].y:
                    event_queue_root = event_queue.insert(event_queue_root, temp)
                    intersec_list.append(temp)

                elif temp != None:
                    above_intersec_list.append(temp)

            structure_queue_root = structure_queue.delete(structure_queue_root, i[0].parent_seg)

        elif i[0].type_of_point == 2:#intersection point
            #recalculate the segments values in order to correctly change their position
            i[0].s2.recalculate_value(i[0].y-0.000001)
            i[0].s1.recalculate_value(i[0].y-0.000001)

            structure_queue.swap(structure_queue_root, [i[0].s1,i[0].s2], found_2, previous)

            structure_queue.neighbors(structure_queue_root, i[0].s2, info_1, found_1)
            if info_1[0] != None and i[0].s1 != None:#delete

                temp = info_1[0].intersection(i[0].s1)
                if temp != None:
                    event_queue_root = event_queue.delete(event_queue_root, temp)


            if info_1[0] != None and i[0].s2 != None:

                temp = info_1[0].intersection(i[0].s2)
                if temp != None and temp.y < i[0].y:
                    event_queue_root = event_queue.insert(event_queue_root, temp)
                    intersec_list.append(temp)

                elif temp != None:
                    above_intersec_list.append(temp)


            found_1 = [0]
            info_1 = [None, None, None];

            structure_queue.neighbors(structure_queue_root, i[0].s1, info_1, found_1)

            if info_1[2] != None and i[0].s2 != None:#delete
                temp = info_1[2].intersection(i[0].s2)
                if temp != None:
                    event_queue_root = event_queue.delete(event_queue_root, temp)

            if info_1[2]!= None and i[0].s1 != None:

                temp = i[0].s1.intersection(info_1[2])

                if temp != None and temp.y < i[0].y:
                    event_queue_root = event_queue.insert(event_queue_root, temp)
                    intersec_list.append(temp)
                elif temp != None:
                    above_intersec_list.append(temp)
