from math import inf
from Point import Point

class Segment():
    ID = 0
    def __init__(self, p1, p2):

        if p1.y>p2.y:
            self.p1 = p2
            self.p2 = p1
        elif p1.y==p2.y and p1.x < p2.y:
            self.p1 = p2
            self.p2 = p1
        else:
            self.p1 = p1
            self.p2 = p2
        self.p2.type_of_point = 0
        self.p1.type_of_point = 1
        self.dx = self.p2.x - self.p1.x
        self.dy = self.p2.y - self.p1.y

        if self.p2.x != self.p1.x:
            self.slope = self.dy / self.dx
            self.yShift = self.p1.y - self.slope * self.p1.x
        else: # vertical segment
            self.slope = inf
            self.yShift = -1. * inf

        self.value = self.p2.x

        self.id = Segment.ID
        Segment.ID += 1

    def recalculate_value(self,y):
        self.value = ((y-self.p2.y)/self.slope)+self.p2.x

    def start(self):#top point
        return self.p1

    def end(self):#bottom point
        return self.p2

    def compare(self, other):
        if self is other : return 0

        dv = self.value - other.value
        if dv > 0: return 1
        if dv < 0: return -1
        else : return -1

        return 0

    def intersection(self, s1):

        xdiff = [self.p1.x - self.p2.x , s1.p1.x - s1.p2.x]
        ydiff = [self.p1.y - self.p2.y , s1.p1.y - s1.p2.y]

        def det(a, b):
              return a[0] * b[1] - a[1] * b[0]

        div = det(xdiff, ydiff)
        if div == 0:
            return None

        d = [det([self.p1.x,self.p1.y],[self.p2.x,self.p2.y]), det([s1.p1.x,s1.p1.y],[s1.p2.x,s1.p2.y])]
        x = det(d, xdiff) / div
        y = det(d, ydiff) / div

        if (s1.p1.y <= y and y <= s1.p2.y)and(self.p1.y <= y and y <= self.p2.y ):
            if s1.p1.x < s1.p2.x:
                highest_x_s1 = s1.p2.x
                lowest_x_s1 = s1.p1.x
            else:
                highest_x_s1 = s1.p1.x
                lowest_x_s1 = s1.p2.x

            if self.p1.x < self.p2.x:
                highest_x_self = self.p2.x
                lowest_x_self = self.p1.x
            else:
                highest_x_self = self.p1.x
                lowest_x_self = self.p2.x

            if (lowest_x_s1 <= x and x <= highest_x_s1) and (lowest_x_self <= x and x <= highest_x_self):

                point = Point([x,y],2)

                if s1.slope < 0 and self.slope < 0:
                    if s1.slope > self.slope:
                        point.s1 = s1
                        point.s2 = self
                    else:
                        point.s1 = self
                        point.s2 = s1

                elif s1.slope > 0 and self.slope > 0:
                    if s1.slope > self.slope:
                        point.s1 = s1
                        point.s2 = self
                    else:
                        point.s1 = self
                        point.s2 = s1

                else:
                    if s1.slope > self.slope:
                        point.s1 = self
                        point.s2 = s1
                    else:
                        point.s1 = s1
                        point.s2 = self

                return point

    def __gt__(self,other):
        # return self.p1 > other.p1
        return self.compare(other) > 0

    def __lt__(self,other):
        # return self.p1 < other.p1
        return self.compare(other) < 0

    def __ge__(self,other):
        # return self.p1 >= other.p1
        return self.compare(other) >= 0

    def __le__(self,other):
        # return self.p1 <= other.p1
        return self.compare(other) <= 0

    def __eq__(self,other):
        if other is None: return False
        # return self.p1 == other.p1
        return self.compare(other) == 0

    def __hash__(self):
        return self.id

    def __repr__(self):
        return '[%d: %s -> %s](%f)'%(self.id,str(self.p1),str(self.p2),self.value)

    def plot(self,color='k'):
        import matplotlib.pyplot as plt
        self.start().plot('b')
        self.end().plot('r')
        v1 = self.start()
        v2 = self.end()
        plt.plot([v1.x,v2.x],[v1.y,v2.y],color)
        x = (v1.x+v2.x)/2
        y = (v1.y+v2.y)/2
        plt.text(x,y,str(self.id))