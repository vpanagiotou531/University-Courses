#include <iostream>
#include <fstream> // To use ifstream
#include <string>

struct metoxi{
	
	//std::string date;
	int date;
	float open, high, low, close;
	int volume, openInt;
};

void savefile(metoxi arr[], std::ifstream &file){
    // Check if exists and then open the file.
    int i=0,c=0; //counter metoxwn
	std::string trash; //gia na petaksoyme tin prwti grammi
	char t; //typou char afou thelw me kapio tropo na elegxw kathe character apo grammi
    
    std::string data; //data before each ','

    if (file.good()) {
     getline(file,trash);
     
		while(!file.eof()){
			
			file.get(t);
				//std::cout<<	t;
			if(t!=','&& t!='\n'&& t!='-') //twra o kwdikas agnwei kai tis pavles '-'
				data+=t;
				
			if(t=='\n'&& c==6 ){
				arr[i].openInt=std::stoi(data);
				data.clear();
				i++;
				c=0;
			}	
				
			if(t==','&& c==5){
				arr[i].volume=std::stoi(data);
				data.clear();
				c++;
			}	
				
			if(t==','&& c==4){
				arr[i].close=std::stof(data);
				data.clear();
				c++;
			}	
				
			if(t==','&& c==3){
				arr[i].low=std::stof(data);
				data.clear();
				c++;
			}	
				
			if(t==','&& c==2){
				arr[i].high=std::stof(data);
				data.clear();
				c++;
			}			
			
			if(t==','&& c==1){
				arr[i].open=std::stof(data);
				data.clear();
				c++;
			}			
			
			if(t==','&& c==0){
				arr[i].date=std::stoi(data); //kanoume to date ena megalo int
				data.clear();
				c++;
			}					
		}			
	}

}//function end

int lineCounter(std::ifstream &file){
	std::string temp; 
   
    int k=0;
     if (file.good()) {
     		while(!file.eof()){
			 getline(file,temp);
			 k++; 
			 }
	 }
	file.clear(); //clear bad state of eof
	file.seekg(0); //resets cursor
	
	//std::cout<<"----------------"<<k-2<<std::endl; //exoume tin prwti grammi pou den metra
	return k-2;									//kai tin teleftaia afksisi tou k pou den metra
}

int BiSearch(metoxi Array[], int tar, int imin, int imax){
	
	if (imax>=imin){  //GIA NA MIN MPAINEI SE INFINITE LOOP
	
	int mid = (imin + imax)/2;
	
		if (Array[mid].date > tar)
			return BiSearch(Array, tar, imin, mid-1);
	
		else if (Array[mid].date < tar)
			return BiSearch(Array, tar, mid+1 , imax);
		
  	 	else
			return mid;
	}
return -1;
}

int InterpolationSearch(metoxi arr[],int size, int tar){
int start, end, pos;
start = 0;
end = size-1;
	while(start <= end && tar>=arr[start].date && tar<=arr[end].date){
		pos = start + (((double)(end-start)/(arr[end].date-arr[start].date))*(tar-arr[start].date));	
	
		if(arr[pos].date==tar)
			return pos;
			
		if(tar>arr[pos].date)
			start=pos+1;
		else
			end=pos-1;
	}
	return -1;
}


void printArray(metoxi array[], int size){
	
	for(int i=0;i<size;i++){
	std::cout<<	array[i].date<<",";
	std::cout<<	array[i].close<<std::endl;
	
	//std::cout<<	array[i].high<<",";
	//std::cout<<	array[i].low<<",";
	//std::cout<<	array[i].close<<",";
	//std::cout<<	array[i].volume<<",";
	//std::cout<<	array[i].openInt<<std::endl;
	}
	std::cout<<"-----------------------------------------------------------"<<std::endl;
}

int main(){
int agnsize, ainvsize, alesize;
std::ifstream agn("agn.us.txt");  // Input file stream object
agnsize = lineCounter(agn);
metoxi agnarr[agnsize]; 
savefile(agnarr,agn);
//printArray(agnarr, agnsize); //Sorted array printed 
agn.close();

std::ifstream ainv("ainv.us.txt"); // Input file stream object
ainvsize = lineCounter(ainv);	
metoxi ainvarr[ainvsize];
savefile(ainvarr,ainv);
ainv.close();

std::ifstream ale("ale.us.txt");  // Input file stream object
alesize = lineCounter(ale);
metoxi alearr[alesize]; 
savefile(alearr,ale);
//printArray(alearr,agnsize);
ale.close();

//User insertion program 
std::string S,temp;
int tar;
std::cout<<"Please insert year of target date in type of YYYY:"<<std::endl;
std::cin>>temp;
S+=temp;
std::cout<<"Please insert month of target date in type of MM:"<<std::endl;
std::cin>>temp;
S+=temp;
std::cout<<"Please insert day of target date in type of DD:"<<std::endl;
std::cin>>temp;
S+=temp;
tar=std::stoi(S);
//int ans=BiSearch(agnarr,tar,0,agnsize);
int ans = InterpolationSearch(ainvarr,ainvsize,tar);
	if(ans==-1)
		std::cout<<"Error date not found"<<std::endl;
	else
		std::cout<<"Summarized volume of exchanges at current Date is: "<<ainvarr[ans].volume;

return 0;
}
