#include <iostream>
#include <fstream> // To use ifstream
#include <string>


struct metoxi{
	
	std::string date;
	float open, high, low, close;
	int volume, openInt;
};

void savefile(metoxi arr[], std::ifstream &file){
    // Check if exists and then open the file.
    int i=0,c=0; //counter metoxwn
	std::string trash; //gia na petaksoyme tin prwti grammi
	char t; //typou char afou thelw me kapio tropo na elegxw kathe character apo grammi
    
    std::string data; //data before each ','

    if (file.good()) {
     getline(file,trash);
     
		while(!file.eof()){
			
			file.get(t);
				//std::cout<<	t;
			if(t!=','&& t!='\n')
				data+=t;
				
			if(t=='\n'&& c==6 ){
				arr[i].openInt = std:: stoi(data);
				data.clear();
				i++;
				c=0;
			}	
				
			if(t==','&& c==5){
				arr[i].volume=std::stoi(data);
				data.clear();
				c++;
			}	
				
			if(t==','&& c==4){
				arr[i].close=std::stof(data);
				data.clear();
				c++;
			}	
				
			if(t==','&& c==3){
				arr[i].low=std::stof(data);
				data.clear();
				c++;
			}	
				
			if(t==','&& c==2){
				arr[i].high=std::stof(data);
				data.clear();
				c++;
			}			
			
			if(t==','&& c==1){
				arr[i].open=std::stof(data);
				data.clear();
				c++;
			}			
			
			if(t==','&& c==0){
				arr[i].date=data;
				data.clear();
				c++;
			}					
		}			
	}

}//function end

int lineCounter(std::ifstream &file){
	std::string temp; 
   
    int k=0;
     if (file.good()) {
     		while(!file.eof()){
			 getline(file,temp);
			 k++; 
			 }
	 }
	file.clear(); //clear bad state of eof
	file.seekg(0); //resets cursor
	
	//std::cout<<"----------------"<<k-2<<std::endl;
	return k-2;
}

void printArray(metoxi array[], int size){
	for(int i=0;i<size;i++){
	std::cout<<	array[i].date<<",";
	std::cout<<	array[i].open<<std::endl;
	
	//std::cout<<	array[i].high<<",";
	//std::cout<<	array[i].low<<",";
	//std::cout<<	array[i].close<<",";
//	std::cout<<	array[i].volume<<",";
//	std::cout<<	array[i].openInt<<std::endl;
	}
	std::cout<<"-----------------------------------------------------------"<<std::endl;
}

void mergeSort(metoxi array[]){

}

void merge(metoxi array[],int left,int middle,int right){

	int size1 = middle - left + 1;
	int size2 = right - middle;

	metoxi array1[size1];
	metoxi array2[size2];

	for (int i = 0; i < size1; i++){
		array1[i] = array[i + left]; // me to i + left pairnoume to prwto stoixeio tou aristerou pinaka
		
	}

	for (int j = 0; j < size2; j++)
	{
		array2[j] = array[middle + j + 1]; // Me to middle + 1 + j pairnoume to prwto stoixeio tou deksiou pinaka
	}	
	
	int i = 0;
    int j = 0;
    int k = left;
    while (i < size1 && j < size2) {
    	
		if (array1[i].open <= array2[j].open) {
			array[k] = array1[i];
            i++;		
        }
        
        else {
        	array[k]= array2[j];
            j++;  
        }
    k++;
    }
 
    while (i < size1) {
        array[k] = array1[i];
        i++;
        k++;
    }
 
    while (j < size2) {
		array[k] = array2[j];
        j++;
        k++; 
	} 
	
}

void mergeSort(metoxi arr[],int l,int r){
    if(l>=r){
        return;
    }
    
    int m = (l+r-1)/2;
    mergeSort(arr,l,m);
    mergeSort(arr,m+1,r);
    merge(arr,l,m,r);
}

int main(){
int agnsize, ainvsize, alesize;
std::ifstream agn("agn.us.txt");  // Input file stream object
agnsize = lineCounter(agn);
metoxi agnarr[agnsize]; 
savefile(agnarr,agn);
//printArray(agnarr,agnsize);
mergeSort(agnarr, 0, agnsize - 1);
//printArray(agnarr, agnsize); //Sorted array printed 

agn.close();

std::ifstream ainv("ainv.us.txt"); // Input file stream object
ainvsize = lineCounter(ainv);	
metoxi ainvarr[ainvsize];
savefile(ainvarr,ainv);
//printArray(ainvarr,ainvsize);
mergeSort(ainvarr, 0, ainvsize - 1);
printArray(ainvarr,ainvsize);

ainv.close();

std::ifstream ale("ale.us.txt");  // Input file stream object
alesize = lineCounter(ale);
metoxi alearr[alesize]; 
savefile(alearr,ale);
//printArray(alearr,agnsize);
ale.close();



return 0;
}
