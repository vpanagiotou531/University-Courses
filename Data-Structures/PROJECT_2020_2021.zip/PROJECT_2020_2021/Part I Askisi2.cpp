#include <iostream>
#include <fstream> // To use ifstream
#include <string>

struct metoxi{
	
	std::string date;
	float open, high, low, close;
	int volume, openInt;
};

void savefile(metoxi arr[], std::ifstream &file){
    // Check if exists and then open the file.
    int i=0,c=0; //counter metoxwn
	std::string trash; //gia na petaksoyme tin prwti grammi
	char t; //typou char afou thelw me kapio tropo na elegxw kathe character apo grammi
    
    std::string data; //data before each ','

    if (file.good()) {
     getline(file,trash);
     
		while(!file.eof()){
			
			file.get(t);
				//std::cout<<	t;
			if(t!=','&& t!='\n')
				data+=t;
				
			if(t=='\n'&& c==6 ){
				arr[i].openInt=std::stoi(data);
				data.clear();
				i++;
				c=0;
			}	
				
			if(t==','&& c==5){
				arr[i].volume=std::stoi(data);
				data.clear();
				c++;
			}	
				
			if(t==','&& c==4){
				arr[i].close=std::stof(data);
				data.clear();
				c++;
			}	
				
			if(t==','&& c==3){
				arr[i].low=std::stof(data);
				data.clear();
				c++;
			}	
				
			if(t==','&& c==2){
				arr[i].high=std::stof(data);
				data.clear();
				c++;
			}			
			
			if(t==','&& c==1){
				arr[i].open=std::stof(data);
				data.clear();
				c++;
			}			
			
			if(t==','&& c==0){
				arr[i].date=data;
				data.clear();
				c++;
			}					
		}			
	}

}//function end

int lineCounter(std::ifstream &file){
	std::string temp; 
    int k=0;
     if (file.good()) {
     		while(!file.eof()){
			 getline(file,temp);
			 k++; 
			 }
	 }
	file.clear(); //clear bad state of eof
	file.seekg(0); //resets cursor
	
//	std::cout<<"----------------"<<k-2<<std::endl; //exoume tin prwti grammi pou den metra
	return k-2;									//kai tin teleftaia afksisi tou k pou den metra
}

void swap(int a , int b , metoxi arr[]){
	metoxi temp[1] = {arr[a]};
	arr[a] = arr[b];
	arr[b] = temp[0];
	
}

void heapify(metoxi arr[], int n, int i) {
    // Find largest among root, left child and right child
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;
  
    if (left < n && arr[left].close > arr[largest].close)
      largest = left;
  
    if (right < n && arr[right].close > arr[largest].close)
      largest = right;

  
    // Swap and continue heapifying if root is not largest
    if (largest != i) {
      swap(i, largest, arr);
      heapify(arr, n, largest);
    }
  }
    
  void heapSort(metoxi arr[], int n) {
    // Build max heap
    for (int i = n / 2 - 1; i >= 0; i--)
      heapify(arr, n, i);
  
    // Heap sort
    for (int i = n - 1; i >= 0; i--) {
      swap(0, i, arr);
  
      // Heapify root element to get highest element at root again
      heapify(arr, i, 0);
    }
  }
  
void printArray(metoxi array[], int size){
	
	for(int i=0;i<size;i++){
	std::cout<<	array[i].date<<",";
	std::cout<<	array[i].close<<std::endl;
	
	//std::cout<<	array[i].high<<",";
	//std::cout<<	array[i].low<<",";
	//std::cout<<	array[i].close<<",";
	//std::cout<<	array[i].volume<<",";
	//std::cout<<	array[i].openInt<<std::endl;
	}
	std::cout<<"-----------------------------------------------------------"<<std::endl;
}


int main(){
int agnsize, ainvsize, alesize;
std::ifstream agn("agn.us.txt");  // Input file stream object
agnsize = lineCounter(agn);
metoxi agnarr[agnsize]; 
savefile(agnarr,agn);
heapSort(agnarr,agnsize);
printArray(agnarr, agnsize); //Sorted array printed 
agn.close();


std::ifstream ainv("ainv.us.txt"); // Input file stream object
ainvsize = lineCounter(ainv);	
metoxi ainvarr[ainvsize];
savefile(ainvarr,ainv);
ainv.close();


std::ifstream ale("ale.us.txt");  // Input file stream object
alesize = lineCounter(ale);
metoxi alearr[alesize]; 
savefile(alearr,ale);
//printArray(alearr,agnsize);
ale.close();


return 0;
}
