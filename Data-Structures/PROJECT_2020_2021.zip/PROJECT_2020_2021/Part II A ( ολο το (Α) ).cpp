#include<iostream>
#include<cmath>
#include<fstream>
#include<string>
#include <iomanip> 

 
struct metoxi{
	
	int date;
	float open, high, low, close;
	int volume, openInt;
};

struct Node{
    metoxi key;
    Node *left;
    Node *right;
    int height;
};

Node *newNode(metoxi key)
{
    Node *node = new Node();
    node->key = key;
    node->right = NULL;
    node->left = NULL;
    node->height = 1;

}

int findMax(int a , int b)
{
    int max = a;
	if(b > a)
		max = b;
	
	return max;
}

int height(Node *n)
{
	if(n == NULL)
		return 0;
	else return n->height;
}

Node *rightRotate(Node *n)
{
	Node *nl = n->left; // nl = node_left
	Node *nlr = nl->right; // nlr = n0de_left_right

	nl->right = n;
	n->left = nlr; 

	n->height = findMax(height(n->left) , height(n->right)) + 1;
	nl->height = findMax(height(nl->left) , height(nl->right)) + 1;

	return nl;
}

Node *leftRotate(Node *n)
{
	Node *nr = n->right; 
	Node *nrl = nr->left; 

	nr->left = n;
	n->right = nrl;

	n->height = findMax(height(n->left) , height(n->right)) + 1;
	nr->height = findMax(height(nr->left) , height(nr->right)) + 1;

	return nr;
}

int getBF(Node *n)
{
	if(n == NULL)
		return 0;
	return height(n->right) - height(n->left);

}

Node* insert(Node *n , metoxi key)
{
	if(n == NULL)
		return(newNode(key));
	
	if(key.date < n->key.date)
		n->left = insert(n->left,key);
	else if(key.date > n->key.date)
		n->right = insert(n->right,key);
	else {
		std::cout << "Equal keys not allowed!!!" << std::endl;
		return n;
		}
	
	n->height = 1 + findMax(height(n->left) , height(n->right));

	int bf = getBF(n);

	// Elegxoume ta 4 cases
	// Left left case
	if(bf < -1 && key.date < n->left->key.date)
		return rightRotate(n);

	// Right right case
	if(bf > 1 && key.date > n->right->key.date)
		return leftRotate(n);

	// left right case
	if(bf < -1 && key.date < n->left->key.date)
	{
		n->right = leftRotate(n->left);
		return rightRotate(n);
	}

	// Right left case
	if(bf > 1 && key.date > n->right->key.date)
	{
		n->right = rightRotate(n->right);
		return leftRotate(n);
	}

	return n;
}

Node* minNode(Node* node)
{
	Node* curr = node;
	while(curr->left != NULL)
		curr = curr->left;
	return curr;
}

Node* deleten(Node* root , int key)
{
	if(root == NULL) 
		return root; // in case the node doesnt have any children
	if(key < root->key.date) // if key is smaller than root key then the node we are searching for is in the left subtree
		root->left = deleten(root->left , key); 
	else if(key > root->key.date)
		root->right = deleten(root->right , key);
	else // if keys are same then the node we want to delete is the node we have
	{
		if((root->left == NULL) || (root->right == NULL)) // checks if a node has 0 or 1 kids
		{
			Node* temp = NULL;
			if(root->left == NULL) // if the left child doesnt exist , store right child in temp
				temp = root->right; // also if right child doesnt exist temp will be NULL
			else  // if left child exists store left in temp instead of right(we start from left always)
				temp = root->left;

			if(temp == NULL) // when the node doesnt have a child
			{
				// temp = root;
				root = NULL;
			}
			else // if node has 1 child
				*root = *temp;

			free(temp);
	    }
		else // if node has 2 children	
		{
			Node* temp = minNode(root->right); // finds the node with the smallest key from the right subtree
			root->key = temp->key; // the elements of the right child now replaces the elements of the parent node
			root->right = deleten(root->right , temp->key.date); // we dont actually delete any node we are just replacing elements so we need to run the delete function in order 
														  // for every node to have the correct elements inside.
		}

	} 
	if (root == NULL) 
    return root; 
  
    root->height = 1 + findMax(height(root->left), 
                           height(root->right)); 
  
    int balance = getBF(root); 
  
	// We now begin to check all the cases one by one
    // Left Left Case 
    if (balance < -1 && 
        getBF(root->left) <= 0) 
        return rightRotate(root); 
  
    // Left Right Case 
    if (balance < -1 && 
        getBF(root->left) > 0) 
    { 
        root->left = leftRotate(root->left); 
        return rightRotate(root); 
    } 
  
    // Right Right Case 
    if (balance > 1 && 
        getBF(root->right) >= 0) 
        return leftRotate(root); 
  
    // Right Left Case 
    if (balance > 1 && 
        getBF(root->right) < 0) 
    { 
        root->right = rightRotate(root->right); 
        return leftRotate(root); 
    } 
  
    return root; 
}

void inorder(Node* n){
	if(n == NULL)
		return;
	inorder(n->left);
	std::cout<<	n->key.date<<std::setw(10);
	std::cout<<	n->key.high<<std::setw(10);
	std::cout<<	n->key.low<<std::setw(10);
	std::cout<<	n->key.close<<std::setw(10);
	std::cout<<	n->key.volume<<std::setw(5);
	std::cout<<	n->key.openInt<<std::endl;
	inorder(n->right);
	//std::cout<<	"-------------------------------"<<std::endl;

}

int search(int tar,Node* n, int change){
	if(n==NULL)
		return -1;
	if(n->key.date==tar){
		if(change>=0)
			n->key.volume=change;
			
		return n->key.volume;
	}
	else if(n->key.date>tar) //if tar smaller then search the left wing
		search(tar,n->left,change);
		
	else if(n->key.date<tar) //if tar bigger then search the right wing
		search(tar,n->right,change);
}

void savefile(metoxi arr[], std::ifstream &file){
    // Check if exists and then open the file.
    int i=0,c=0; //counter metoxwn
	std::string trash; //gia na petaksoyme tin prwti grammi
	char t; //typou char afou thelw me kapio tropo na elegxw kathe character apo grammi
    
    std::string data; //data before each ','

    if (file.good()) {
     getline(file,trash);
     
		while(!file.eof()){
			
			file.get(t);
				//std::cout<<	t;
			if(t!=','&& t!='\n'&& t!='-') //twra o kwdikas agnwei kai tis pavles '-'
				data+=t;
				
			if(t=='\n'&& c==6 ){
				arr[i].openInt=std::stoi(data);
				data.clear();
				i++;
				c=0;
			}	
				
			if(t==','&& c==5){
				arr[i].volume=std::stoi(data);
				data.clear();
				c++;
			}	
				
			if(t==','&& c==4){
				arr[i].close=std::stof(data);
				data.clear();
				c++;
			}	
				
			if(t==','&& c==3){
				arr[i].low=std::stof(data);
				data.clear();
				c++;
			}	
				
			if(t==','&& c==2){
				arr[i].high=std::stof(data);
				data.clear();
				c++;
			}			
			
			if(t==','&& c==1){
				arr[i].open=std::stof(data);
				data.clear();
				c++;
			}			
			
			if(t==','&& c==0){
				arr[i].date=std::stoi(data); //kanoume to date ena megalo int
				data.clear();
				c++;
			}					
		}			
	}

}//function end

int lineCounter(std::ifstream &file){
	std::string temp; 
   
    int k=0;
     if (file.good()) {
     		while(!file.eof()){
			 getline(file,temp);
			 k++; 
			 }
	 }
	file.clear(); //clear bad state of eof
	file.seekg(0); //resets cursor
	
	//std::cout<<"----------------"<<k-2<<std::endl;
	return k-2;
}

void printArray(metoxi array[], int size){
	
	for(int i=0;i<size;i++){
	std::cout<<	array[i].date<<",";
	std::cout<<	array[i].open<<std::endl;
	
	//std::cout<<	array[i].high<<",";
	//std::cout<<	array[i].low<<",";
	//std::cout<<	array[i].close<<",";
	//std::cout<<	array[i].volume<<",";
	//std::cout<<	array[i].openInt<<std::endl;
	}
	//std::cout<<"-----------------------------------------------------------"<<std::endl;
}


int main(){
int agnsize, ainvsize, alesize;
Node *root=NULL;
std::ifstream agn("agn.us.txt");  // Input file stream object
agnsize = lineCounter(agn);
metoxi agnarr[agnsize]; 
savefile(agnarr,agn);
//printArray(agnarr, agnsize); // array printed 
for (int i=0;i<agnsize;i++){
	root = insert(root,agnarr[i]);
}


std::cout<<"  Date\t     Open      High\t  Low\t Volume\t OpenInt"<<std::endl;
inorder(root);
agn.close();

std::ifstream ainv("ainv.us.txt"); // Input file stream object
ainvsize = lineCounter(ainv);	
metoxi ainvarr[ainvsize];
savefile(ainvarr,ainv);
ainv.close();

std::ifstream ale("ale.us.txt");  // Input file stream object
alesize = lineCounter(ale);
metoxi alearr[alesize]; 
savefile(alearr,ale);
ale.close();

std::string temp, S;
char answer;
int tar,volchange;
std::cout<<"Please insert year of target date in type of YYYY:"<<std::endl;
std::cin>>temp;
S+=temp;
std::cout<<"Please insert month of target date in type of MM:"<<std::endl;
std::cin>>temp;
S+=temp;
std::cout<<"Please insert day of target date in type of DD:"<<std::endl;
std::cin>>temp;
S+=temp;
tar=std::stoi(S);

/*
std::cout<<"Do you want to change the volume at target Date?(y/n)"<<std::endl;

while(answer!='n' && answer!='y'){
	std::cout<<"Wrong answer please try again:"<<std::endl;
	std::cin>>answer;	
}

if(answer=='n'){
int vol = search(tar,root,-1); //volchange is by default -1 so the algorithm can run without problems
	if(vol==-1)
		std::cout<<"Error date not found"<<std::endl;
	else
		std::cout<<"Summarized volume of exchanges at current Date is: "<<vol;
}
if(answer=='y'){
std::cout<<"insert Volume Change at target Date"<<std::endl;
std::cin>>volchange;
int vol = search(tar,root,volchange); //volchange is now bigger than -1 so the volume will be changed
	if(vol==-1)
		std::cout<<"Error date not found"<<std::endl;
	else
		std::cout<<"Summarized volume of exchanges at current Date is: "<<vol;
}
*/

root = deleten(root,tar);
inorder(root);
system("pause");
return 0;

}
