#include<iostream>
#include<cmath>
#include<fstream>
#include<string>
#include<iomanip> //std::setw()
 #include <algorithm> //std::transform
struct metoxi{
	
	int date;
	float open, high, low, close;
	int volume, openInt;
};

struct Node{
    metoxi key;
    Node *left;
    Node *right;
    int height;
};

Node *newNode(metoxi key)
{
    Node *node = new Node();
    node->key = key;
    node->right = NULL;
    node->left = NULL;
    node->height = 1;

}

int findMax(int a , int b)
{
    int max = a;
	if(b > a)
		max = b;
	
	return max;
}

int height(Node *n)
{
	if(n == NULL)
		return 0;
	else return n->height;
}

Node *rightRotate(Node *n)
{
	Node *nl = n->left; // nl = node_left
	Node *nlr = nl->right; // nlr = n0de_left_right

	nl->right = n;
	n->left = nlr; 

	n->height = findMax(height(n->left) , height(n->right)) + 1;
	nl->height = findMax(height(nl->left) , height(nl->right)) + 1;

	return nl;
}

Node *leftRotate(Node *n)
{
	Node *nr = n->right; 
	Node *nrl = nr->left; 

	nr->left = n;
	n->right = nrl;

	n->height = findMax(height(n->left) , height(n->right)) + 1;
	nr->height = findMax(height(nr->left) , height(nr->right)) + 1;

	return nr;
}

int getBF(Node *n)
{
	if(n == NULL)
		return 0;
	return height(n->right) - height(n->left);

}

Node* insert(Node *n , metoxi key)
{
	if(n == NULL)
		return(newNode(key));
	
	if(key.date < n->key.date)
		n->left = insert(n->left,key);
	else if(key.date > n->key.date)
		n->right = insert(n->right,key);
	else {
		std::cout << "Equal keys not allowed!!!" << std::endl;
		return n;
		}
	
	n->height = 1 + findMax(height(n->left) , height(n->right));

	int bf = getBF(n);

	// Elegxoume ta 4 cases
	// Left left case
	if(bf < -1 && key.date < n->left->key.date)
		return rightRotate(n);

	// Right right case
	if(bf > 1 && key.date > n->right->key.date)
		return leftRotate(n);

	// left right case
	if(bf < -1 && key.date < n->left->key.date)
	{
		n->right = leftRotate(n->left);
		return rightRotate(n);
	}

	// Right left case
	if(bf > 1 && key.date > n->right->key.date)
	{
		n->right = rightRotate(n->right);
		return leftRotate(n);
	}

	return n;
}

Node* minNode(Node* node)
{
	Node* curr = node;
	while(curr->left != NULL)
		curr = curr->left;
	return curr;
}

Node* deleten(Node* root , int key)
{
	if(root == NULL) 
		return root; // in case the node doesnt have any children
	if(key < root->key.date) // if key is smaller than root key then the node we are searching for is in the left subtree
		root->left = deleten(root->left , key); 
	else if(key > root->key.date)
		root->right = deleten(root->right , key);
	else // if keys are same then the node we want to delete is the node we have
	{
		if((root->left == NULL) || (root->right == NULL)) // checks if a node has 0 or 1 kids
		{
			Node* temp = NULL;
			if(root->left == NULL) // if the left child doesnt exist , store right child in temp
				temp = root->right; // also if right child doesnt exist temp will be NULL
			else  // if left child exists store left in temp instead of right(we start from left always)
				temp = root->left;

			if(temp == NULL) // when the node doesnt have a child
			{
				// temp = root;
				root = NULL;
			}
			else // if node has 1 child
				*root = *temp;

			free(temp);
	    }
		else // if node has 2 children	
		{
			Node* temp = minNode(root->right); // finds the node with the smallest key from the right subtree
			root->key = temp->key; // the elements of the right child now replaces the elements of the parent node
			root->right = deleten(root->right , temp->key.date); // we dont actually delete any node we are just replacing elements so we need to run the delete function in order 
														  // for every node to have the correct elements inside.
		}

	} 
	if (root == NULL) 
    return root; 
  
    root->height = 1 + findMax(height(root->left), 
                           height(root->right)); 
  
    int balance = getBF(root); 
  
	// We now begin to check all the cases one by one
    // Left Left Case 
    if (balance < -1 && 
        getBF(root->left) <= 0) 
        return rightRotate(root); 
  
    // Left Right Case 
    if (balance < -1 && 
        getBF(root->left) > 0) 
    { 
        root->left = leftRotate(root->left); 
        return rightRotate(root); 
    } 
  
    // Right Right Case 
    if (balance > 1 && 
        getBF(root->right) >= 0) 
        return leftRotate(root); 
  
    // Right Left Case 
    if (balance > 1 && 
        getBF(root->right) < 0) 
    { 
        root->right = rightRotate(root->right); 
        return leftRotate(root); 
    } 
  
    return root; 
}

void inorder(Node* n){
	if(n == NULL)
		return;
	inorder(n->left);
	std::cout<<	n->key.date<<std::setw(10);
	std::cout<<	n->key.high<<std::setw(10);
	std::cout<<	n->key.low<<std::setw(10);
	std::cout<<	n->key.close<<std::setw(10);
	std::cout<<	n->key.volume<<std::setw(5);
	std::cout<<	n->key.openInt<<std::endl;
	inorder(n->right);
	//std::cout<<	"-------------------------------"<<std::endl;

}

int search(int tar, Node* n, int change){
	if(n==NULL)
		return -1;
	if(n->key.date==tar){
		if(change>=0)
			n->key.volume=change;
			
		return n->key.volume;
	}
	else if(n->key.date>tar) //if tar smaller then search the left wing
		search(tar,n->left,change);
		
	else if(n->key.date<tar) //if tar bigger then search the right wing
		search(tar,n->right,change);
}

void savefile(metoxi arr[], std::ifstream &file){
    // Check if exists and then open the file.
    int i=0,c=0; //counter metoxwn
	std::string trash; //gia na petaksoyme tin prwti grammi
	char t; //typou char afou thelw me kapio tropo na elegxw kathe character apo grammi
    
    std::string data; //data before each ','

    if (file.good()) {
     getline(file,trash);
     
		while(!file.eof()){
			
			file.get(t);
				//std::cout<<	t;
			if(t!=','&& t!='\n'&& t!='-') //twra o kwdikas agnwei kai tis pavles '-'
				data+=t;
				
			if(t=='\n'&& c==6 ){
				arr[i].openInt=std::stoi(data);
				data.clear();
				i++;
				c=0;
			}	
				
			if(t==','&& c==5){
				arr[i].volume=std::stoi(data);
				data.clear();
				c++;
			}	
				
			if(t==','&& c==4){
				arr[i].close=std::stof(data);
				data.clear();
				c++;
			}	
				
			if(t==','&& c==3){
				arr[i].low=std::stof(data);
				data.clear();
				c++;
			}	
				
			if(t==','&& c==2){
				arr[i].high=std::stof(data);
				data.clear();
				c++;
			}			
			
			if(t==','&& c==1){
				arr[i].open=std::stof(data);
				data.clear();
				c++;
			}			
			
			if(t==','&& c==0){
				arr[i].date=std::stoi(data); //kanoume to date ena megalo int
				data.clear();
				c++;
			}					
		}			
	}

}//function end

int lineCounter(std::ifstream &file){
	std::string temp; 
   
    int k=0;
     if (file.good()) {
     		while(!file.eof()){
			 getline(file,temp);
			 k++; 
			 }
	 }
	file.clear(); //clear bad state of eof
	file.seekg(0); //resets cursor
	
	//std::cout<<"----------------"<<k-2<<std::endl;
	return k-2;
}

void printArray(metoxi array[], int size){
	
	for(int i=0;i<size;i++){
	std::cout<<	array[i].date<<",";
	std::cout<<	array[i].open<<std::endl;
	
	//std::cout<<	array[i].high<<",";
	//std::cout<<	array[i].low<<",";
	//std::cout<<	array[i].close<<",";
	//std::cout<<	array[i].volume<<",";
	//std::cout<<	array[i].openInt<<std::endl;
	}
	//std::cout<<"-----------------------------------------------------------"<<std::endl;
}

int getdate(){
	std::string temp, S;
	char answer;
	int tar,volchange;
	std::cout<<"Please insert year of target date in type of YYYY:"<<std::endl;
	std::cin>>temp;
	S+=temp;
	std::cout<<"Please insert month of target date in type of MM:"<<std::endl;
	std::cin>>temp;
	S+=temp;
	std::cout<<"Please insert day of target date in type of DD:"<<std::endl;
	std::cin>>temp;
	S+=temp;
	tar=std::stoi(S);	
return tar;
}

int main(){
int agnsize;
std::ifstream agn("agn.us.txt");  // Input file stream object
agnsize = lineCounter(agn); //gets array size
metoxi agnarr[agnsize]; 	
savefile(agnarr,agn);	//moves file to array
agn.close();


std::string answer;
std::cout<<"Greetings\nDo you want to Load the agn.txt file in AVL tree or HASHING?\nType Avl or Hashing"<<std::endl;
int c=0;
while(answer.compare("avl")!=0 && answer.compare("hashing")!=0){ //Security code for wrong input
	if(c>0) //ignores the first input
		std::cout<<"Wrong answer please choose \"Avl\" or \"Hashing" <<std::endl;
		
	std::cin>>answer;
	transform(answer.begin(), answer.end(), answer.begin(), ::tolower); //transforms the string to lowercase	
	c++;
}

if(answer.compare("avl")==0){ //AVL MENU
	std::cout<<"You have chosen to load the agn.txt file in an AVL Tree. Do you want it sorted based on Date or Stock Exchange Volume?"<<std::endl;
	std::string choice;
	c=0;
	while(choice.compare("date")!=0 && choice.compare("volume")!=0){ //Security code for wrong input
		if(c>0) //ignores the first input
			std::cout<<"Wrong answer please choose \"Date\" or \"Volume" <<std::endl;
			
		std::cin>>choice;
		transform(choice.begin(), choice.end(), choice.begin(), ::tolower); //transforms the string to lowercase	
		c++;
	}
	
	if(choice.compare("date")==0){
			
		Node *root=NULL;
		for (int i=0;i<agnsize;i++){ //creates avl with insert() fuction which is based on Date
			root = insert(root,agnarr[i]);
		}
		
		do{	
			switch(0){ //interval switch
				case 0:
				break;
			}
			std::cout<<"------------------------------------------------"<<std::endl;
			std::cout<<"1) Print Avl Tree in an inorder fashion\n2) Search Stock exchange Volume based on Date"<<std::endl; 	
			std::cout<<"3) Change specific Stock exchange Volume based on Date"<<std::endl;
			std::cout<<"4) Delete Specific Entry based on Date\n5) Exit program\n------------------------------------------------"<<std::endl;
			int menu;
			std::cin>>menu;
			switch(menu)
			{
				case 1:{
					std::cout<<"  Date\t     Open      High\t  Low\t Volume\t OpenInt"<<std::endl;
					inorder(root);	
					break;
				}
			
				case 2:{					
					int tar = getdate();
					int vol = search(tar,root,-1); //volchange is by default -1 so the algorithm can run without problems
					if(vol==-1)
						std::cout<<"Error date not found"<<std::endl;
					else
						std::cout<<"Summarized Stock exchange Volume at current Date is: "<<vol<<std::endl;
					break;
				}
			
				case 3:{
					int tar = getdate(), volchange;	
					std::cout<<"Please insert NEW Stock exchange Volume target Date: "<<std::endl;
					std::cin>>volchange;
					int vol = search(tar,root,volchange); //volchange is now bigger than -1 so the volume will be changed
					if(vol==-1)
						std::cout<<"Error date not found"<<std::endl;
					else
						std::cout<<"Summarized Stock exchange Volume at current Date has beem succesfully changed!\n";	
					break;
				}
				
				case 4:{
					int tar = getdate(), volchange;
					int vol = search(tar,root,-1);
					if(vol==-1)
						std::cout<<"Error date not found"<<std::endl;
					else{
						root = deleten(root,tar);
						std::cout<<"Entry has been succesfully deleted!\n";
						}
					break;
				}
				
				case 5:{
					std::cout<<"Thank you =^.^="<<std::endl;
					exit(0);
					//break;
				}
				default:
					std::cout<<"Wrong answer please choose numbers between 1 and 5" <<std::endl;	
			}
		}while(!false); //menu switch
	}//for date implementation
	
	if(choice.compare("volume")==0){
		std::cout<<"Not Yet implemented, blame the devs"<<std::endl;
	}
}// Avl

if(answer.compare("hashing")==0){
	std::cout<<"Not Yet implemented, blame the devs"<<std::endl;
} //Hashing 

return 0;
}
