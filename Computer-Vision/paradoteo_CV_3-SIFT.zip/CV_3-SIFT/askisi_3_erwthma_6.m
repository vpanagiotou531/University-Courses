% Read the images
img1 = imread('igem.jpg');  
img2 = imread('monalisa.jpg');  

% % Μετατροπή των εικόνων σε ασπρόμαυρες εάν δεν είναι ήδη
% Η συνάρτηση im2gray μετατρέπει τις εισαγωγικές εικόνες σε ασπρόμαυρες ανεξαρτήτως του εάν είναι ήδη ασπρόμαυρες ή χρωματιστές. Αυτό είναι σημαντικό επειδή οι αλγόριθμοι ανίχνευσης χαρακτηριστικών όπως ο SURF συνήθως λειτουργούν σε εικόνες μονού καναλιού.
img1_gray = im2gray(img1);
img2_gray = im2gray(img2);

% Detect SURF features
%Τα χαρακτηριστικά SURF ανιχνεύονται σε και τις δύο εικόνες κλίμακας γκρι χρησιμοποιώντας τη συνάρτηση detectSURFFeatures.
%Τα ανιχνευμένα σημεία χαρακτηριστικών αποθηκεύονται στις μεταβλητές points1 και points2.
points1 = detectSURFFeatures(img1_gray);
points2 = detectSURFFeatures(img2_gray);

% Extract features
% Τα χαρακτηριστικά εξάγονται από τα ανιχνευμένα σημεία χρησιμοποιώντας τη συνάρτηση extractFeatures.
% Αυτό το βήμα υπολογίζει περιγραφείς για κάθε ανιχνευμένο σημείο χαρακτηριστικού, οι οποίοι χρησιμοποιούνται για την αντιστοίχιση.
% Τα εξαγόμενα χαρακτηριστικά και τα αντίστοιχα έγκυρα σημεία αποθηκεύονται στις μεταβλητές features1, valid_points1, features2 και valid_points2 αντίστοιχα.
[features1, valid_points1] = extractFeatures(img1_gray, points1);
[features2, valid_points2] = extractFeatures(img2_gray, points2);

% Match features
% Αντιστοίχιση Χαρακτηριστικών:
% Τα χαρακτηριστικά από τις δύο εικόνες αντιστοιχίζονται χρησιμοποιώντας τη συνάρτηση matchFeatures.
% Αυτή η συνάρτηση επιστρέφει ένα σύνολο ζευγών δεικτών που υποδεικνύουν τα αντιστοιχισμένα χαρακτηριστικά μεταξύ των δύο εικόνων.
% Τα ζευγάρια δεικτών αποθηκεύονται στη μεταβλητή indexPairs.
indexPairs = matchFeatures(features1, features2);

% Retrieve the locations of the corresponding points for each image
% Σε αυτό το τμήμα του κώδικα, οι αντίστοιχες τοποθεσίες των σημείων για κάθε εικόνα ανακτώνται με βάση τα ζευγάρια δεικτών που προέκυψαν από την αντιστοίχιση χαρακτηριστικών. Αυτό σημαίνει ότι χρησιμοποιούνται οι δείκτες που προκύπτουν από τη σύσταση των χαρακτηριστικών που ταιριάζουν στις δύο εικόνες, ώστε να ανακτηθούν οι αντίστοιχες τοποθεσίες των σημείων σε κάθε εικόνα.
matchedPoints1 = valid_points1(indexPairs(:, 1), :);
matchedPoints2 = valid_points2(indexPairs(:, 2), :);

% Display the matching points
% τα αντίστοιχα σημεία που έχουν ανακτηθεί χρησιμοποιούνται για να εμφανιστούν στον χρήστη. Δημιουργείται μια νέα εικόνα χρησιμοποιώντας την συνάρτηση showMatchedFeatures, όπου τα σημεία που ταιριάζουν προβάλλονται πάνω στις αρχικές εικόνες. Τα σημεία αυτά αναπαρίστανται από τις μεταβλητές matchedPoints1 και matchedPoints2.
figure; ax = axes;
showMatchedFeatures(img1_gray, img2_gray, matchedPoints1, matchedPoints2, 'montage', 'Parent', ax);
title(ax, 'Candidate point matches using built-in MATLAB functions');
legend(ax, 'Matched points 1', 'Matched points 2');
