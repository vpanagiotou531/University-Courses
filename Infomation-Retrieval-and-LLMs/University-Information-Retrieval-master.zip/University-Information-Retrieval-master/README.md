This is my university project for Information Retrieval
